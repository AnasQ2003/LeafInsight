import os
import io
import re
import requests
import numpy as np
from PIL import Image
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import tensorflow as tf
import openai

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
API_TOKEN = os.getenv("API_TOKEN", "my-secret-token")

if not OPENAI_API_KEY:
    raise ValueError("⚠️ OpenAI API key not found. Set OPENAI_API_KEY in environment variables.")

client = openai.OpenAI(api_key=OPENAI_API_KEY)

model = tf.keras.models.load_model("plant_disease_model.keras")

class_names = [
    "Tomato_healthy",
    "Bell_Pepper_bacterial_spot",
    "Potato_Early_blight",
    "Bell_Pepper_healthy",
    "Potato_healthy",
    "Tomato_mosaic_virus",
    "Potato_Late_blight",
    "Unknown_Objects"
]

CLASS_MAPPING = {
    "Potato_Early_blight": ("Potato", "Early blight"),
    "Potato_Late_blight": ("Potato", "Late blight"),
    "Potato_healthy": ("Potato", "Healthy"),
    "Tomato_healthy": ("Tomato", "Healthy"),
    "Tomato_mosaic_virus": ("Tomato", "Mosaic virus"),
    "Bell_Pepper_bacterial_spot": ("Bell Pepper", "Bacterial spot"),
    "Bell_Pepper_healthy": ("Bell Pepper", "Healthy"),
}

PLANT_TRANSLATIONS = {
    "Potato": "آلو",
    "Tomato": "ٹماٹر",
    "Bell Pepper": "شملہ مرچ",
}

DISEASE_TRANSLATIONS = {
    "Healthy": "صحت مند",
    "Early blight": "آگ جلنے کی ابتدائی بیماری",
    "Late blight": "آگ جلنے کی آخری بیماری",
    "Bacterial spot": "بیکٹیریا کی دھبے",
    "Mosaic virus": "موزیک وائرس"
}

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ImageRequest(BaseModel):
    token: str
    imageUrl: str
    language: str = "en"

def preprocess_image_from_url(url: str) -> np.ndarray:
    try:
        response = requests.get(url)
        response.raise_for_status()
        img = Image.open(io.BytesIO(response.content)).convert("RGB")
        img = img.resize((224, 224))  
        img_array = np.array(img) / 255.0
        return np.expand_dims(img_array, axis=0)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Image processing failed: {e}")


def get_blog_prompt(language: str) -> str:
    if language.lower() == "ur":
        return (
            "درج ذیل معلومات کی بنیاد پر ایک تفصیلی بلاگ بنائیں:\n"
            "- پودے کا نام\n"
            "- بیماری (اگر ہو)\n"
            "- اعتماد کی شرح\n"
            "- علامات، وجوہات، علاج، دیکھ بھال\n"
            "- کم از کم 100 الفاظ\n"
            "- markdown فارمیٹ میں لکھیں، سرخیاں اور **اہم الفاظ** استعمال کریں\n"
            "- اگر پودا صحت مند ہو تو صرف دیکھ بھال کی تجاویز دیں"
        )
    else:
        return (
            "Write a detailed markdown blog using the following information:\n"
            "- Plant name\n"
            "- Disease (if any)\n"
            "- Confidence percentage\n"
            "- Symptoms, causes, treatment, and care tips\n"
            "- At least 100 words\n"
            "- Use markdown format with headings and **bold** keywords\n"
            "- If the plant is healthy, give care suggestions only"
        )

@app.get("/")
def root():
    return {"message": "FastAPI is running with Keras + GPT!"}

@app.post("/predict")
async def predict(data: ImageRequest, authorization: str = Header(None)):
    is_token_valid = (
        data.token == API_TOKEN or
        authorization == f"Bearer {API_TOKEN}"
    )
    if not is_token_valid:
        raise HTTPException(status_code=401, detail="Unauthorized")

    image = preprocess_image_from_url(data.imageUrl)

    predictions = model.predict(image)[0]
    class_idx = int(np.argmax(predictions))
    confidence = float(predictions[class_idx]) * 100
    label = class_names[class_idx]

    OOD_THRESHOLD = 90
    if confidence < OOD_THRESHOLD or label == "Unknown_Objects":
        return {"error": "Picture cannot be identified"}

    plant, disease = CLASS_MAPPING.get(label, ("Unknown", "Unknown"))

    if data.language.lower() == "ur":
        plant = PLANT_TRANSLATIONS.get(plant, plant)
        disease = DISEASE_TRANSLATIONS.get(disease, disease)

    user_prompt = (
        f"Plant: {plant}\n"
        f"Disease: {disease}\n"
        f"Confidence: {confidence:.2f}%"
    )
    system_prompt = get_blog_prompt(data.language)

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        max_tokens=1000
    )

    gpt_content = response.choices[0].message.content.strip()
    cleaned_response = re.sub(r"```(json|markdown)?\n|\n```", "", gpt_content).strip()

    return {
        "plantName": plant,
        "diseaseName": disease,
        "mdBlog": cleaned_response
    }

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
