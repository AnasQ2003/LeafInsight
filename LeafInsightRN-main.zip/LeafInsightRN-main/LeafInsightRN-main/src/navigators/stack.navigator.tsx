import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

//Screens
import Home from '../screens/app/Home.tsx';
import LoginScreen from '../screens/auth/Login.tsx';
import SignUpScreen from '../screens/auth/SignUp.tsx';
import ForgotPasswordScreen from '../screens/auth/ForgotPassword.tsx';
import EditProfileScreen from '../screens/app/EditProfile.tsx';
import { AuthStackParamList, AppStackParamList } from '../types/navigation.types';
import TabsNavigator from './tabs.navigator.tsx';
import { useUserStore } from '../store/reducer/user.ts';
import DynamicView from '../screens/app/DynamicView.tsx';
import CameraScreen from '../screens/app/CameraScreen.tsx';
import PreviewScreen from '../screens/app/PreviewScreen.tsx';

export const RootNavigator = ({}) => {
  const { user } = useUserStore();
  const isLoggedIn = !!user?.token;
  return isLoggedIn ? <AppStackNavigator /> : <AuthStackNavigator />;
};

const AuthStack = createNativeStackNavigator<AuthStackParamList>();
const AuthStackNavigator = () => {
  return (
    <AuthStack.Navigator screenOptions={{ headerShown: false }}>
      <AuthStack.Screen name="Login" component={LoginScreen} />
      <AuthStack.Screen name="SignUp" component={SignUpScreen} />
      <AuthStack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
    </AuthStack.Navigator>
  );
};

const AppStack = createNativeStackNavigator<AppStackParamList>();

const AppStackNavigator = () => {
  return (
    <AppStack.Navigator screenOptions={{ headerShown: false }} initialRouteName="BottomTabs">
      <AppStack.Screen name="BottomTabs" component={TabsNavigator} />
      <AppStack.Screen name="EditProfile" component={EditProfileScreen} />
      <AppStack.Screen name="CameraScreen" component={CameraScreen} />
      <AppStack.Screen name="PreviewScreen" component={PreviewScreen} />
      <AppStack.Screen name="DynamicView" component={DynamicView} />
    </AppStack.Navigator>
  );
};
