import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Home from '../screens/app/Home';
import Profile from '../screens/app/Profile';
import NewScanScreen from '../screens/app/NewScan';
import { View, Text } from 'react-native';
import { Image } from 'react-native';
import icons from '../assets/icons';
import { useTheme } from '../constants/size';

const Tab = createBottomTabNavigator();

const TabsNavigator = () => {
  const theme = useTheme();
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarStyle: {
          backgroundColor: theme.colors.BACKGROUND,
          borderTopWidth: 0,
          borderTopLeftRadius: theme.sizes.BORDER_RADIUS * 2,
          borderTopRightRadius: theme.sizes.BORDER_RADIUS * 2,
          height: theme.sizes.HEIGHT * 0.08,
          paddingTop: theme.sizes.PADDING,
        },
        tabBarShowLabel: false,
        headerShown: false,
      }}>
      <Tab.Screen
        name="Home"
        component={Home}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabBarIcon focused={focused} icon={icons.HOME} label="Home" iconFocused={icons.HOME_SELECTED} />
          ),
        }}
      />
      <Tab.Screen
        name="NewScan"
        component={NewScanScreen}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabBarIcon
              focused={focused}
              icon={icons.NEW_SCAN}
              label="New Scan"
              iconFocused={icons.NEW_SCAN_SELECTED}
            />
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={Profile}
        options={{
          tabBarIcon: ({ focused }) => (
            <TabBarIcon focused={focused} icon={icons.PROFILE} label="Profile" iconFocused={icons.PROFILE_SELECTED} />
          ),
        }}
      />
    </Tab.Navigator>
  );
};

export default TabsNavigator;

interface TabBarIconProps {
  focused: boolean;
  icon: any;
  label: string;
  iconFocused: any;
}

const TabBarIcon = ({ focused, icon, label, iconFocused }: TabBarIconProps) => {
  const theme = useTheme();
  return (
    <View
      style={{
        alignItems: 'center',
        justifyContent: 'center',
        width: theme.sizes.WIDTH * 0.25,
      }}>
      <Image
        style={{
          width: theme.sizes.ICON,
          height: theme.sizes.ICON,
        }}
        source={focused ? iconFocused : icon}
        resizeMode="contain"
      />
    </View>
  );
};
