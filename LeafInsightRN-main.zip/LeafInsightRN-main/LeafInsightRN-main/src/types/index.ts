interface User {
  id: number;
  name: string;
  email: string;
  username: string;
  token: string;
}

interface StrapiImage {
  id: 1;
  formats: {
    thumbnail: {
      url: '/uploads/thumbnail_logo_1cdcf7f057.png';
    };
  };
  url: '/uploads/logo_1cdcf7f057.png';
}

interface Blog {
  id: number;
  title: string;
  image: StrapiImage;
  shortDescription: string;
  description: string;
  createdAt: string;
}

interface Scan {
  id: number;
  image: StrapiImage;
  plantName: string;
  diseaseName: string;
  mdBlog: string;
  createdAt: string;
}

interface Pagination {
  page: number;
  pageSize: number;
  pageCount: number;
  total: number;
}

interface DynamicPage {
  id: number;
  url: string;
  title: string;
  md: string;
  createdAt: string;
}

interface Strings {
  BLOG: string;
  HISTORY: string;
  HI: string;
  NO_BLOGS_FOUND: string;
  NO_PREVIOUS_SCANS: string;
  BACK: string;
  SELECT_FROM_GALLERY: string;
  USE_CAMERA: string;
  CAMERA_PERMISSION_REQUIRED: string;
  REQUEST_PERMISSION: string;
  NO_CAMERA_DEVICE_FOUND: string;
  RETAKE: string;
  CONFIRM: string;
  LOGOUT: string;
  LOGOUT_MESSAGE: string;
  CANCEL: string;
  LANGUAGE: string;
  ABOUT_US: string;
  TERMS_AND_CONDITIONS: string;
  FORGOT_PASSWORD: string;
  FORGOT_PASSWORD_MESSAGE: string;
  LOGIN: string;
  SEND_RESET_LINK: string;
  EMAIL: string;
  PASSWORD: string;
  SIGN_UP: string;
  DONT_HAVE_AN_ACCOUNT: string;
  ALREADY_HAVE_AN_ACCOUNT: string;
  CREATE_ACCOUNT: string;
  FULL_NAME: string;
  CONFIRM_PASSWORD: string;
  REQUIRED: string;
  INVALID_EMAIL: string;
  MIN_8_CHARACTERS: string;
  PASSWORDS_MUST_MATCH: string;
  WELCOME_BACK: string;
  SELECT_LANGUAGE: string;
}
