import { NativeStackNavigationProp } from '@react-navigation/native-stack';

export type AuthStackParamList = {
  Login: undefined;
  SignUp: undefined;
  ForgotPassword: undefined;
};

export type AuthStackNavigationProp = NativeStackNavigationProp<AuthStackParamList>;

export type AppStackParamList = {
  BottomTabs: undefined;
  EditProfile: undefined;
  CameraScreen: undefined;
  PreviewScreen: {
    photo: string;
  };
  DynamicView: {
    title?: string;
    md?: string;
    url?: string;
  };
};

export type AppStackNavigationProp = NativeStackNavigationProp<AppStackParamList>;
