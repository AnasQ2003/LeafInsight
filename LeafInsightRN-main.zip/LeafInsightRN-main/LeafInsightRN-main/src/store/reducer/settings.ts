import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { useSelector } from 'react-redux';
import { RootState } from '../store';
import { useMemo } from 'react';
import { string } from 'yup';
import { enStrings } from '../../constants/locales';
import { urStrings } from '../../constants/locales';

// init states
const initState = {
  settings: {
    langID: 'en',
  },
};

export interface Settings {
  settings: {
    langID: string;
  };
}

// reducer
const settings = createSlice({
  name: 'settings',
  initialState: initState,
  reducers: {
    setSettings(state, action: PayloadAction<Partial<Settings['settings']>>) {
      state.settings = { ...state.settings, ...action.payload };
    },
  },
});

export const { setSettings } = settings.actions;
export default settings.reducer;

interface SettingsStore {
  langID: string;
  isRTL: boolean;
  strings: Strings;
}

export const useSettingsStore = (): SettingsStore => {
  const settings = useSelector((state: RootState) => state.settings.settings);

  const strings = useMemo(() => {
    const strings = settings?.langID === 'ur' ? urStrings : enStrings;
    return new Proxy(strings, {
      get(target, prop: string) {
        return prop in target ? target[prop as keyof typeof target] : prop;
      },
    });
  }, []);

  return {
    ...settings,
    isRTL: settings.langID === 'ur',
    strings: strings as any,
  };
};
