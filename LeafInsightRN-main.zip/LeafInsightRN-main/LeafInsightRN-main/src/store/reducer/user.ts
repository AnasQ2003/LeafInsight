import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { useSelector } from 'react-redux';
import { RootState } from '../store';

export interface UserStore {
  user: User | null;
}

const initState: UserStore = {
  user: null,
};

const user = createSlice({
  name: 'user',
  initialState: initState,
  reducers: {
    setUser(state, action: PayloadAction<User | null>) {
      state.user = action.payload;
    },

    clearUser(state) {
      state.user = null;
    },
  },
});

export const { setUser, clearUser } = user.actions;
export default user.reducer;

export const useUserStore = () => {
  const user = useSelector((state: RootState) => state.user.user);

  return {
    user,
  };
};
