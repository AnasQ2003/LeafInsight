import { useColorScheme } from 'react-native';

const defaultColors = {
  PRIMARY: '#31A444',
  PRIMARY_TEXT: 'white',
  SKY_BLUE: '#3db6fc',
  RED: '#ff1605',
  GREEN: '#18c900',
  GRAY: '#808080',
  BLACK: 'black',
  WHITE: 'white',
};

const colorsLight = {
  ...defaultColors,
  isDark: false,
  BACKGROUND: 'white',
  PRIMARY_BACKGROUND: '#F1F5F9',
  TEXT: 'black',
  LIGHT_GRAY: '#c1c7c2',
  GRAY: 'grey',
};

export type Colors = typeof colorsLight;

export const useColors = () => {
  return colorsLight;
};
