const apiEndPoints = {
  BASE_URL: `https://leafinsight.cgpax.online`,
  LOGIN: `/api/auth/local`,
  REGISTER: `/api/auth/local/register`,
  CREATE_SCAN: `/api/scans`,
  GET_SCANS: (page: number) => `/api/scans?page=${page}&pageSize=10`,
  BLOGS: (page: number, locale: string) => `/api/blogs?page=${page}&pageSize=10&locale=${locale}`,
  DYNAMIC_PAGE: (url: string, locale: string) => `/api/dynamic-pages/${url}?locale=${locale}`,
};

export default apiEndPoints;
