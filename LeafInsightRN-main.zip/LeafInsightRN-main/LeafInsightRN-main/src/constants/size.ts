import { useMemo } from 'react';
import { useWindowDimensions } from 'react-native';
import { useColors } from './color';
import { getGlobalStyles } from './globalStyles';

const getSizes = (width: number, height: number) => ({
  WIDTH: width,
  HEIGHT: height,
  PADDING: width * 0.03,
  PADDED_WIDTH: width - width * 0.06,
  FONTSIZE: 14,
  FONTSIZE_HIGH: 18,
  FONTSIZE_SMALL: 10,
  ICON: width * 0.06,
  HEADER_FOOTER_SIZE: height * 0.1,
  BORDER_RADIUS: 10,
  BORDER_RADIUS_HIGH: 15,
});

export type Sizes = ReturnType<typeof getSizes>;

export const useSizes = () => {
  const { width, height } = useWindowDimensions();
  return useMemo(() => getSizes(width, height), [width, height]);
};

export const useTheme = () => {
  const sizes = useSizes();
  const colors = useColors();
  const globalStyles = getGlobalStyles(colors, sizes);
  return { sizes, colors, globalStyles };
};
