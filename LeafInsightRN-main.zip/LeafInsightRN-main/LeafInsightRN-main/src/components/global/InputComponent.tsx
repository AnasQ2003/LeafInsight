import { Image, ImageStyle, StyleSheet, TextInput, TextInputProps, View, ViewStyle } from 'react-native';
import React, { useMemo } from 'react';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import { useColors } from '../../constants/color';
import { useSettingsStore } from '../../store/reducer/settings';

type Props = {
  icon?: any;
  fieldProps: TextInputProps;
  containerStyle?: ViewStyle;
  iconStyle?: ImageStyle;
  error?: any;
};

const InputComponent = ({ fieldProps, containerStyle, icon, iconStyle, error }: Props) => {
  const { colors, styles } = useStyles();
  const { isRTL } = useSettingsStore();
  return (
    <View
      style={[
        styles.container,
        {
          borderWidth: error ? 1 : 1,
          borderColor: error ? colors.RED : colors.BACKGROUND,
        },
        containerStyle,
      ]}>
      {icon && <Image source={icon} style={[styles.image, iconStyle]} />}
      <TextInput
        placeholderTextColor={colors.LIGHT_GRAY}
        style={[styles.input, { textAlign: isRTL ? 'right' : 'left' }]}
        {...fieldProps}
      />
    </View>
  );
};

export default InputComponent;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          width: '100%',
          borderRadius: sizes.BORDER_RADIUS,
          flexDirection: 'row',
          paddingHorizontal: sizes.PADDING,
          alignItems: 'center',
          backgroundColor: colors.BACKGROUND,
        },
        input: {
          flex: 1,
          ...globalStyles.TEXT_STYLE,
        },
        image: {
          width: sizes.ICON * 0.5,
          height: sizes.ICON * 0.5,
          marginRight: sizes.PADDING,
        },
      }),
    [],
  );

  return {
    colors,
    sizes,
    globalStyles,
    styles,
  };
};
