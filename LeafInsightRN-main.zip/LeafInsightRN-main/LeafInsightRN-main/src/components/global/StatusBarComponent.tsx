import React from 'react';
import { SafeAreaView, View, StatusBar } from 'react-native';
import { useTheme } from '../../constants/size';

const StatusBarComponent = () => {
  const { globalStyles, colors, sizes } = useTheme();

  return (
    <View
      style={{
        height: StatusBar.currentHeight,
        backgroundColor: colors.BACKGROUND,
      }}>
      <SafeAreaView>
        <StatusBar
          translucent
          backgroundColor={colors.BACKGROUND}
          barStyle={colors.isDark ? 'light-content' : 'dark-content'}
        />
      </SafeAreaView>
    </View>
  );
};

export default StatusBarComponent;
