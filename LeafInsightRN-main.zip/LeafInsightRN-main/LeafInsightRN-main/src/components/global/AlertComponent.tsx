import { View, Modal, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useSizes } from '../../constants/size';
import { useColors } from '../../constants/color';
import { useMemo } from 'react';
import { getGlobalStyles } from '../../constants/globalStyles';

type Props = {
  onOkPress: () => void;
  text?: string;
  isVisible: boolean;
  okText?: string;
  noText?: string;
  onNoPress?: () => void;
  headerText?: string;
};

const AlertComponent = ({
  isVisible,
  text = 'Are you sure?',
  okText = 'OK',
  noText = 'Cancel',
  onNoPress,
  onOkPress,
  headerText = 'Alert',
}: Props) => {
  const { styles, sizes, colors } = useStyles();

  return (
    <Modal animationType="none" transparent={true} visible={isVisible}>
      <View style={styles.centeredView}>
        <View style={styles.lModalView}>
          <Text style={styles.headerText}>{headerText}</Text>
          <Text style={styles.msgText}>{text}</Text>
          <View style={{ flexDirection: 'row', gap: sizes.PADDING * 1.5, width: '100%', justifyContent: 'flex-end' }}>
            {!!noText && (
              <TouchableOpacity onPress={onNoPress} style={styles.noBox}>
                <Text style={styles.noText}>{noText}</Text>
              </TouchableOpacity>
            )}
            {!!okText && (
              <TouchableOpacity onPress={onOkPress} style={styles.okBox}>
                <Text style={styles.okText}>{okText}</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default AlertComponent;

const useStyles = () => {
  const sizes = useSizes();
  const colors = useColors();
  const globalStyles = getGlobalStyles(colors, sizes);
  const styles = useMemo(
    () =>
      StyleSheet.create({
        centeredView: {
          height: sizes.HEIGHT,
          width: sizes.WIDTH,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: 'rgba(0,0,0,0.5)',
        },
        lModalView: {
          padding: sizes.PADDING * 1.5,
          width: sizes.WIDTH * 0.8,
          backgroundColor: 'white',
          borderRadius: sizes.BORDER_RADIUS_HIGH,
        },
        msgText: {
          ...globalStyles.TEXT_STYLE,
          color: colors.TEXT,
          marginBottom: sizes.PADDING * 2,
        },
        headerText: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
          color: colors.TEXT,
        },
        okBox: {
          paddingVertical: sizes.PADDING * 0.75,
          paddingHorizontal: sizes.PADDING * 2.5,
          backgroundColor: colors.PRIMARY,
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: sizes.BORDER_RADIUS,
        },
        okText: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.WIDTH * 0.03,
          color: colors.PRIMARY_TEXT,
        },
        noBox: {
          backgroundColor: 'white',
          justifyContent: 'center',
          alignItems: 'center',
        },
        noText: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.WIDTH * 0.03,
          color: colors.GRAY,
        },
      }),
    [sizes, colors],
  );

  return {
    styles,
    sizes,
    colors,
  };
};
