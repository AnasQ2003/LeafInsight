import { View, Modal, StyleSheet, TouchableOpacity } from 'react-native';
import { useSizes } from '../../constants/size';
import { useMemo } from 'react';

type Props = {
  isVisible: boolean;
  children: React.ReactNode;
  onClose: () => void;
};

const CenterModal = ({ isVisible, children, onClose }: Props) => {
  const { styles } = useStyles();
  return (
    <Modal animationType="fade" transparent={true} visible={isVisible}>
      <TouchableOpacity activeOpacity={1} style={styles.centeredView} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} onPress={e => e.stopPropagation()}>
          {children}
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
};

export default CenterModal;

const useStyles = () => {
  const sizes = useSizes();

  const styles = useMemo(
    () =>
      StyleSheet.create({
        centeredView: {
          height: sizes.HEIGHT,
          width: sizes.WIDTH,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: 'rgba(0,0,0,0.7)',
        },
      }),
    [sizes],
  );

  return {
    styles,
    sizes,
  };
};
