import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  FlatList,
  Modal,
  ViewStyle,
  TextStyle,
  Image,
} from 'react-native';
import React, { useCallback, useMemo, useState } from 'react';
import { useTheme } from '../../constants/size';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import icons from '../../assets/icons';

export type DropdownOption = {
  label: string;
  value: string | number;
};

type Props = {
  label?: string;
  options: DropdownOption[];
  selectedValue?: string | number;
  onSelect: (option: DropdownOption) => void;
  placeholder?: string;
  containerStyle?: ViewStyle;
  labelStyle?: TextStyle;
  error?: string;
  disabled?: boolean;
  searchPlaceholder?: string;
};

const DropDownSelect = ({
  label,
  options,
  selectedValue,
  onSelect,
  placeholder = 'Select an option',
  containerStyle,
  labelStyle,
  error,
  disabled = false,
  searchPlaceholder = 'Search...',
}: Props) => {
  const { styles, colors, sizes } = useStyles();
  const [modalVisible, setModalVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const selectedOption = useMemo(() => {
    return options.find(option => option.value === selectedValue);
  }, [options, selectedValue]);

  const filteredOptions = useMemo(() => {
    if (!searchQuery.trim()) return options;
    return options.filter(option => option.label.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [options, searchQuery]);

  const toggleModal = useCallback(() => {
    if (!disabled) {
      setModalVisible(!modalVisible);
      setSearchQuery('');
    }
  }, [disabled, modalVisible]);

  const handleSelect = useCallback(
    (option: DropdownOption) => {
      onSelect(option);
      setModalVisible(false);
    },
    [onSelect],
  );

  const renderItem = useCallback(
    ({ item }: { item: DropdownOption }) => (
      <TouchableOpacity style={styles.optionItem} onPress={() => handleSelect(item)}>
        <Text style={[styles.optionText, item.value === selectedValue && styles.selectedOptionText]}>{item.label}</Text>
        {item.value === selectedValue && <Text style={styles.checkmark}>✓</Text>}
      </TouchableOpacity>
    ),
    [handleSelect, selectedValue, styles],
  );

  return (
    <View style={[styles.container, containerStyle]}>
      {label && <Text style={[styles.label, labelStyle]}>{label}</Text>}

      <TouchableOpacity
        style={[
          styles.selectButton,
          {
            borderColor: error ? colors.RED : colors.BACKGROUND,
            backgroundColor: disabled ? colors.LIGHT_GRAY : colors.BACKGROUND,
          },
        ]}
        onPress={() => {
          setSearchQuery('');
          setModalVisible(true);
        }}
        disabled={disabled}>
        <Text style={[styles.selectedText, !selectedOption && styles.placeholderText]}>
          {selectedOption ? selectedOption.label : placeholder}
        </Text>
        <Image source={icons.ARROW_LEFT} style={styles.dropdownIcon} />
      </TouchableOpacity>

      {error && <Text style={styles.errorText}>{error}</Text>}

      <Modal visible={modalVisible} transparent animationType="slide" onRequestClose={toggleModal}>
        <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={toggleModal}>
          <View style={styles.modalContent} onStartShouldSetResponder={() => true}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{label}</Text>
              <TouchableOpacity onPress={toggleModal}>
                <Text style={styles.closeButton}>✕</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.searchContainer}>
              <TextInput
                style={styles.searchInput}
                placeholder={searchPlaceholder}
                value={searchQuery}
                onChangeText={setSearchQuery}
                autoCorrect={false}
                clearButtonMode="while-editing"
              />
            </View>

            <FlatList
              style={{
                height: sizes.HEIGHT * 0.2,
              }}
              data={filteredOptions}
              renderItem={renderItem}
              keyExtractor={item => item.value.toString()}
              showsVerticalScrollIndicator={false}
              ListEmptyComponent={<Text style={styles.emptyList}>No options found</Text>}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
};

export default DropDownSelect;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          width: '100%',
          marginBottom: sizes.PADDING,
        },
        label: {
          ...globalStyles.TEXT_STYLE_BOLD,
          marginBottom: sizes.PADDING / 2,
        },
        selectButton: {
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          paddingHorizontal: sizes.PADDING,
          paddingVertical: sizes.PADDING * 0.8,
          borderWidth: 1,
          borderRadius: sizes.BORDER_RADIUS,
          height: 45,
        },
        selectedText: {
          ...globalStyles.TEXT_STYLE,
        },
        placeholderText: {
          color: colors.LIGHT_GRAY,
        },
        dropdownIcon: {
          color: colors.GRAY,
          width: sizes.WIDTH * 0.05,
          height: sizes.WIDTH * 0.05,
          transform: [{ rotate: '-90deg' }],
        },
        errorText: {
          ...globalStyles.TEXT_STYLE,
          color: colors.RED,
          fontSize: sizes.FONTSIZE_SMALL,
          marginTop: 5,
        },
        modalOverlay: {
          flex: 1,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          justifyContent: 'flex-end',
        },
        modalContent: {
          backgroundColor: colors.BACKGROUND,
          borderTopLeftRadius: sizes.BORDER_RADIUS_HIGH,
          borderTopRightRadius: sizes.BORDER_RADIUS_HIGH,
          paddingVertical: sizes.PADDING,
          maxHeight: sizes.HEIGHT * 0.7,
        },
        modalHeader: {
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingHorizontal: sizes.PADDING,
          marginBottom: sizes.PADDING,
        },
        modalTitle: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
        },
        closeButton: {
          fontSize: sizes.FONTSIZE_HIGH,
          color: colors.GRAY,
          padding: 5,
        },
        searchContainer: {
          paddingHorizontal: sizes.PADDING,
          marginBottom: sizes.PADDING,
        },
        searchInput: {
          ...globalStyles.TEXT_STYLE,
          borderWidth: 1,
          borderColor: colors.LIGHT_GRAY,
          borderRadius: sizes.BORDER_RADIUS,
          paddingHorizontal: sizes.PADDING,
          height: 40,
        },
        optionItem: {
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingVertical: sizes.PADDING * 0.8,
          paddingHorizontal: sizes.PADDING,
          borderBottomWidth: 0.5,
          borderBottomColor: colors.LIGHT_GRAY,
        },
        optionText: {
          ...globalStyles.TEXT_STYLE,
        },
        selectedOptionText: {
          ...globalStyles.TEXT_STYLE_BOLD,
          color: colors.PRIMARY,
        },
        checkmark: {
          color: colors.PRIMARY,
          fontSize: sizes.FONTSIZE_HIGH,
        },
        emptyList: {
          ...globalStyles.TEXT_STYLE,
          textAlign: 'center',
          padding: sizes.PADDING,
          color: colors.GRAY,
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
