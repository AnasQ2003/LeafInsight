import { View, Text, TouchableOpacity, ViewStyle, TextStyle } from 'react-native';
import React from 'react';
import { useTheme } from '../../constants/size';
import fonts from '../../assets/fonts';

interface RadioButtonProps {
  label: string;
  selected: boolean;
  onPress: () => void;
  containerStyle?: ViewStyle;
  labelStyle?: TextStyle;
}

const RadioButton: React.FC<RadioButtonProps> = ({ label, selected, onPress, containerStyle, labelStyle }) => {
  const theme = useTheme();

  return (
    <TouchableOpacity
      style={[
        {
          flexDirection: 'row',
          alignItems: 'center',
          gap: theme.sizes.PADDING,
        },
        containerStyle,
      ]}
      onPress={onPress}>
      <View
        style={{
          width: 20,
          height: 20,
          borderRadius: 10,
          borderWidth: 2,
          borderColor: selected ? theme.colors.PRIMARY : theme.colors.PRIMARY,
          backgroundColor: selected ? theme.colors.PRIMARY : 'transparent',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        {selected && (
          <View
            style={{
              width: 8,
              height: 8,
              borderRadius: 4,
              backgroundColor: theme.colors.BACKGROUND,
            }}
          />
        )}
      </View>
      <Text
        style={[
          {
            ...theme.globalStyles.TEXT_STYLE,
            fontFamily: fonts.APP_FONT_REGULAR,
            color: theme.colors.TEXT,
          },
          labelStyle,
        ]}>
        {label}
      </Text>
    </TouchableOpacity>
  );
};

export default RadioButton;
