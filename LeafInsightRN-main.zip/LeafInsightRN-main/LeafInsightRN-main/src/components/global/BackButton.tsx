import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View, Image, StyleProp, ViewStyle } from 'react-native';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import icons from '../../assets/icons';
import { useSettingsStore } from '../../store/reducer/settings';

interface BackButtonProps {
  onPress: () => void;
  title?: string;
  containerStyle?: StyleProp<ViewStyle>;
  color?: string;
}

const BackButton: React.FC<BackButtonProps> = ({ onPress, title, containerStyle, color }) => {
  const { styles, colors, sizes } = useStyles();
  const { isRTL } = useSettingsStore();

  return (
    <TouchableOpacity style={[styles.container, containerStyle]} onPress={onPress}>
      <Image
        source={icons.ARROW_LEFT}
        style={[
          styles.icon,
          { tintColor: color ? color : colors.PRIMARY, transform: [{ rotate: isRTL ? '180deg' : '0deg' }] },
        ]}
      />
      {title && <Text style={[styles.text, { color: color ? color : colors.PRIMARY }]}>{title}</Text>}
    </TouchableOpacity>
  );
};

export default BackButton;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = StyleSheet.create({
    container: {
      flexDirection: 'row',
      alignItems: 'center',
      position: 'absolute',
      top: sizes.PADDING,
      left: sizes.PADDING,
    },
    icon: {
      width: 24,
      height: 24,
      bottom: -1,
    },
    text: {
      ...globalStyles.TEXT_STYLE_BOLD,
      fontSize: sizes.FONTSIZE,
      marginStart: sizes.PADDING / 2,
    },
  });

  return {
    styles,
    colors,
    sizes,
  };
};
