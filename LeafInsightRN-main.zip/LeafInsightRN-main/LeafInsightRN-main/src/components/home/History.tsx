import { FlatList, Image, Text, TouchableOpacity, View, ActivityIndicator, RefreshControl } from 'react-native';
import { useTheme } from '../../constants/size';
import { getTimeAgo } from '../../utils';
import { useState, useEffect } from 'react';
import { _getScans } from '../../utils/api-helper';
import { useNavigation } from '@react-navigation/native';
import { AppStackNavigationProp } from '../../types/navigation.types';
import { loadImage } from '../../utils';
import { useUserStore } from '../../store/reducer/user';
import { useSettingsStore } from '../../store/reducer/settings';

interface HistoryProps {
  scans: Scan[];
  scansPage: number;
  setScansPage: (page: number | ((prevPage: number) => number)) => void;
  setScansLastPage: (lastPage: boolean) => void;
  setScans: (scans: Scan[]) => void;
  scansLastPage: boolean;
}

const History = ({ scans, scansPage, setScansPage, setScansLastPage, setScans, scansLastPage }: HistoryProps) => {
  const theme = useTheme();
  const navigation = useNavigation<AppStackNavigationProp>();
  const [loading, setLoading] = useState(false);
  const { user } = useUserStore();

  const fetchData = async (page?: number) => {
    if (loading) return;
    setLoading(true);

    const res = await _getScans(page || scansPage, user?.token!);

    if (res) {
      const pagination = res?.meta?.pagination;

      if (pagination?.page === 1) {
        setScans(res?.data || []);
      } else {
        setScans([...scans, ...(res?.data || [])]);
      }

      if (pagination?.page !== undefined) {
        setScansPage(pagination.page);
      }

      if (pagination?.pageCount === pagination?.page || res?.data?.length === 0) {
        setScansLastPage(true);
      }
    }

    setLoading(false);
  };

  useEffect(() => {
    if (scansLastPage) return;
    fetchData();
  }, [scansPage]);

  const { strings } = useSettingsStore();

  return (
    <View style={{ flex: 1, padding: theme.sizes.PADDING }}>
      <FlatList
        refreshControl={
          <RefreshControl
            refreshing={loading}
            onRefresh={() => {
              fetchData(1);
            }}
          />
        }
        showsVerticalScrollIndicator={false}
        data={scans}
        contentContainerStyle={{ gap: theme.sizes.PADDING }}
        keyExtractor={(item, index) => index.toString()}
        ListEmptyComponent={
          !loading ? (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: theme.sizes.PADDING * 2 }}>
              <Text style={{ ...theme.globalStyles.TEXT_STYLE, color: theme.colors.GRAY }}>
                {strings.NO_PREVIOUS_SCANS}
              </Text>
            </View>
          ) : null
        }
        onEndReached={() => {
          if (!scansLastPage && !loading) setScansPage((p: number) => p + 1);
        }}
        renderItem={({ item }) => (
          <HistoryCard
            onPress={() => {
              navigation.navigate('DynamicView', {
                title: item.plantName,
                md: item.mdBlog,
              });
            }}
            history={item}
          />
        )}
        ListFooterComponent={loading ? <ActivityIndicator size="large" color={theme.colors.PRIMARY} /> : null}
      />
    </View>
  );
};

export default History;

const HistoryCard = ({ history, onPress }: { history: Scan; onPress: () => void }) => {
  const theme = useTheme();
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={{
        backgroundColor: theme.colors.BACKGROUND,
        padding: theme.sizes.PADDING / 2,
        borderRadius: theme.sizes.BORDER_RADIUS,
        flexDirection: 'row',
        alignItems: 'center',
        gap: theme.sizes.PADDING,
      }}>
      <Image
        source={{ uri: loadImage(history.image)?.view() }}
        style={{
          height: theme.sizes.HEIGHT * 0.1,
          backgroundColor: theme.colors.LIGHT_GRAY,
          aspectRatio: 1,
          borderRadius: theme.sizes.BORDER_RADIUS,
        }}
      />
      <View style={{ flex: 1 }}>
        <Text numberOfLines={1} style={{ ...theme.globalStyles.TEXT_STYLE_BOLD, fontSize: theme.sizes.FONTSIZE_HIGH }}>
          {history.plantName}
        </Text>
        <Text numberOfLines={2} style={{ ...theme.globalStyles.TEXT_STYLE, width: theme.sizes.WIDTH * 0.65 }}>
          {history.diseaseName}
        </Text>
        <Text style={{ ...theme.globalStyles.TEXT_STYLE, color: theme.colors.GRAY }}>
          {getTimeAgo(history.createdAt)}
        </Text>
      </View>
    </TouchableOpacity>
  );
};
