import { FlatList, Image, Text, TouchableOpacity, View, ActivityIndicator, RefreshControl } from 'react-native';
import { useTheme } from '../../constants/size';
import { useNavigation } from '@react-navigation/native';
import { AppStackNavigationProp } from '../../types/navigation.types';
import { useState } from 'react';
import { useEffect } from 'react';
import { _getBlogs } from '../../utils/api-helper';
import { loadImage } from '../../utils';
import { useSettingsStore } from '../../store/reducer/settings';
interface BlogsProps {
  blogs: Blog[];
  setBlogs: (blogs: Blog[]) => void;
  blogsPage: number;
  setBlogsPage: any;
  blogsLastPage: boolean;
  setBlogsLastPage: any;
}
const Blogs = ({ blogs, setBlogs, blogsPage, setBlogsPage, blogsLastPage, setBlogsLastPage }: BlogsProps) => {
  const theme = useTheme();
  const navigation = useNavigation<AppStackNavigationProp>();

  const [loading, setLoading] = useState(false);

  const fetchBlogs = async (page?: number) => {
    if (loading) return;
    setLoading(true);
    const res = await _getBlogs(page || blogsPage);

    if (res) {
      const pagination = res?.meta?.pagination;

      if (pagination?.page === 1) {
        setBlogs(res?.data || []);
      } else {
        setBlogs([...blogs, ...(res?.data || [])]);
      }

      setBlogsPage(pagination?.page);
      if (pagination?.pageCount === pagination?.page || res?.data?.length === 0) {
        setBlogsLastPage(true);
      }
    }

    setLoading(false);
  };

  useEffect(() => {
    if (blogsLastPage) return;
    fetchBlogs();
  }, [blogsPage]);

  const { strings } = useSettingsStore();

  return (
    <View style={{ flex: 1, padding: theme.sizes.PADDING }}>
      <FlatList
        showsVerticalScrollIndicator={false}
        data={blogs}
        contentContainerStyle={{ gap: theme.sizes.PADDING }}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={() => fetchBlogs(1)} />}
        keyExtractor={(item, index) => index.toString()}
        ListEmptyComponent={
          !loading ? (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: theme.sizes.PADDING * 2 }}>
              <Text style={{ ...theme.globalStyles.TEXT_STYLE, color: theme.colors.GRAY }}>
                {strings.NO_BLOGS_FOUND}
              </Text>
            </View>
          ) : null
        }
        onEndReached={() => {
          if (!blogsLastPage && !loading) setBlogsPage((p: any) => p + 1);
        }}
        renderItem={({ item, index }) => (
          <BlogCard
            onPress={() => {
              navigation.navigate('DynamicView', {
                title: strings.BLOG,
                md: item.description,
              });
            }}
            blog={{
              ...item,
              title: item.title + index,
            }}
          />
        )}
        ListFooterComponent={loading ? <ActivityIndicator size="large" color={theme.colors.PRIMARY} /> : null}
      />
    </View>
  );
};

export default Blogs;

const BlogCard = ({ blog, onPress }: { blog: Blog; onPress: () => void }) => {
  const theme = useTheme();
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.7}
      style={{
        backgroundColor: theme.colors.BACKGROUND,
        padding: theme.sizes.PADDING / 2,
        borderRadius: theme.sizes.BORDER_RADIUS,
        flexDirection: 'row',
        alignItems: 'center',
        gap: theme.sizes.PADDING,
      }}>
      <Image
        source={{ uri: loadImage(blog.image)?.view() }}
        style={{
          height: theme.sizes.HEIGHT * 0.1,
          backgroundColor: theme.colors.LIGHT_GRAY,
          aspectRatio: 1,
          borderRadius: theme.sizes.BORDER_RADIUS,
        }}
      />
      <View style={{ flex: 1 }}>
        <Text numberOfLines={1} style={{ ...theme.globalStyles.TEXT_STYLE_BOLD, fontSize: theme.sizes.FONTSIZE_HIGH }}>
          {blog.title}
        </Text>
        <Text numberOfLines={2} style={{ ...theme.globalStyles.TEXT_STYLE, width: theme.sizes.WIDTH * 0.65 }}>
          {blog.shortDescription}
        </Text>
        <Text style={{ ...theme.globalStyles.TEXT_STYLE, color: theme.colors.GRAY }}>
          {new Date(blog.createdAt).toLocaleDateString('en-US', {
            dateStyle: 'medium',
          })}
        </Text>
      </View>
    </TouchableOpacity>
  );
};
