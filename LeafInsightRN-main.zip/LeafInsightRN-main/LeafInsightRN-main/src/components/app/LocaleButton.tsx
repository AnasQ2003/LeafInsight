import { View, Text, TouchableOpacity, Image, ViewStyle, I18nManager } from 'react-native';
import React, { useState } from 'react';
import icons from '../../assets/icons';
import CenterModal from '../global/CenterModal';
import { useTheme } from '../../constants/size';
import fonts from '../../assets/fonts';
import RadioButton from '../global/RadioButton';
import { setSettings, useSettingsStore } from '../../store/reducer/settings';
import { useDispatch } from 'react-redux';
import RNRestart from 'react-native-restart';
interface Props {
  containerStyle?: ViewStyle;
}

const languages = [
  {
    name: 'English',
    code: 'en',
  },
  {
    name: 'Urdu (اردو)',
    code: 'ur',
  },
];

const LocaleButton = ({ containerStyle }: Props) => {
  const [isVisible, setIsVisible] = useState(false);

  return (
    <>
      <TouchableOpacity style={containerStyle} onPress={() => setIsVisible(true)}>
        <Image
          source={icons.LANGUAGE}
          style={{
            width: 24,
            height: 24,
          }}
        />
      </TouchableOpacity>
      <LocalModal isVisible={isVisible} setIsVisible={setIsVisible} />
    </>
  );
};

export default LocaleButton;

interface LocalModalProps {
  isVisible: boolean;
  setIsVisible: (isVisible: boolean) => void;
}

export const LocalModal = ({ isVisible, setIsVisible }: LocalModalProps) => {
  const theme = useTheme();

  const { langID, strings } = useSettingsStore();

  const dispatch = useDispatch();

  const handleLocaleChange = (code: string) => {
    if (code === langID) {
      setIsVisible(false);
      return;
    }
    dispatch(setSettings({ langID: code }));
    setTimeout(() => {
      I18nManager.forceRTL(code === 'ur');
      RNRestart.Restart();
    }, 1000);
  };

  return (
    <CenterModal isVisible={isVisible} onClose={() => setIsVisible(false)}>
      <View
        style={{
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: theme.colors.BACKGROUND,
          width: theme.sizes.WIDTH * 0.9,
          padding: theme.sizes.PADDING,
          borderRadius: theme.sizes.BORDER_RADIUS,
        }}>
        <Text style={{ ...theme.globalStyles.TEXT_STYLE_BOLD, fontSize: theme.sizes.FONTSIZE_HIGH }}>
          {strings.SELECT_LANGUAGE}
        </Text>
        <View style={{ width: '100%', gap: theme.sizes.PADDING, marginVertical: theme.sizes.PADDING }}>
          {languages.map((language, index) => (
            <TouchableOpacity
              key={index}
              style={{ flexDirection: 'row', alignItems: 'center', gap: theme.sizes.PADDING / 2 }}
              onPress={() => {
                handleLocaleChange(language.code);
              }}>
              <RadioButton
                label={''}
                selected={language.code === langID}
                onPress={() => {
                  setIsVisible(false);
                }}
              />
              <Text style={{ ...theme.globalStyles.TEXT_STYLE, fontFamily: fonts.APP_FONT_SEMIBOLD }}>
                {language.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </CenterModal>
  );
};
