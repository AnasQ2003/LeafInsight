import React from 'react';
import { StyleSheet } from 'react-native';
import Markdown from 'react-native-markdown-display';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import fonts from '../../assets/fonts';

interface StyledMarkdownProps {
  children: string;
}

const StyledMarkdown: React.FC<StyledMarkdownProps> = ({ children }) => {
  const { colors, sizes } = useStyles();

  return (
    <Markdown
      style={{
        body: {
          color: colors.TEXT,
          fontFamily: fonts.APP_FONT_REGULAR,
          fontSize: sizes.FONTSIZE,
          lineHeight: sizes.FONTSIZE * 1.5,
        },
        heading1: {
          fontFamily: fonts.APP_FONT_BOLD,
          fontSize: sizes.FONTSIZE_HIGH * 1.5,
          color: colors.PRIMARY,
          marginTop: sizes.PADDING * 1.5,
          marginBottom: sizes.PADDING,
          paddingVertical: sizes.PADDING,
        },
        heading2: {
          fontFamily: fonts.APP_FONT_BOLD,
          fontSize: sizes.FONTSIZE_HIGH * 1.2,
          color: colors.PRIMARY,
          marginTop: sizes.PADDING * 1.2,
          marginBottom: sizes.PADDING * 0.8,
        },
        heading3: {
          fontFamily: fonts.APP_FONT_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
          color: colors.PRIMARY,
          marginTop: sizes.PADDING,
          marginBottom: sizes.PADDING * 0.5,
        },
        heading4: {
          fontFamily: fonts.APP_FONT_SEMIBOLD,
          fontSize: sizes.FONTSIZE_HIGH * 0.9,
          color: colors.PRIMARY,
          marginTop: sizes.PADDING * 0.8,
          marginBottom: sizes.PADDING * 0.4,
        },
        heading5: {
          fontFamily: fonts.APP_FONT_SEMIBOLD,
          fontSize: sizes.FONTSIZE_HIGH * 0.8,
          color: colors.PRIMARY,
          marginTop: sizes.PADDING * 0.6,
          marginBottom: sizes.PADDING * 0.3,
        },
        heading6: {
          fontFamily: fonts.APP_FONT_SEMIBOLD,
          fontSize: sizes.FONTSIZE,
          color: colors.PRIMARY,
          marginTop: sizes.PADDING * 0.5,
          marginBottom: sizes.PADDING * 0.2,
        },
        paragraph: {
          fontFamily: fonts.APP_FONT_REGULAR,
          fontSize: sizes.FONTSIZE,
          lineHeight: sizes.FONTSIZE * 1.5,
          marginBottom: sizes.PADDING,
          color: colors.TEXT,
        },
        strong: {
          fontFamily: fonts.APP_FONT_BOLD,
          color: colors.TEXT,
        },
        em: {
          fontFamily: fonts.APP_FONT_MEDIUM,
          color: colors.TEXT,
        },
        s: {
          textDecorationLine: 'line-through',
          color: colors.GRAY,
        },
        code_inline: {
          fontFamily: 'monospace',
          backgroundColor: colors.LIGHT_GRAY,
          color: colors.PRIMARY,
          padding: 2,
          borderRadius: 3,
        },
        bullet_list: {
          marginBottom: sizes.PADDING,
        },
        ordered_list: {
          marginBottom: sizes.PADDING,
        },
        list_item: {
          marginBottom: sizes.PADDING / 2,
          flexDirection: 'row',
          alignItems: 'flex-start',
        },
        link: {
          fontFamily: fonts.APP_FONT_REGULAR,
          color: colors.PRIMARY,
          textDecorationLine: 'underline',
        },
        image: {
          alignSelf: 'center',
          marginVertical: sizes.PADDING,
          borderRadius: sizes.BORDER_RADIUS,
          objectFit: 'cover',
        },

        code_block: {
          backgroundColor: colors.LIGHT_GRAY,
          padding: sizes.PADDING * 0.8,
          borderRadius: sizes.BORDER_RADIUS,
          fontFamily: 'monospace',
          fontSize: sizes.FONTSIZE * 0.9,
          color: colors.PRIMARY,
          marginVertical: sizes.PADDING,
        },
        table: {
          borderWidth: 0.5,
          borderColor: colors.LIGHT_GRAY,
          borderRadius: sizes.BORDER_RADIUS,
          marginVertical: sizes.PADDING,
        },
        table_header: {
          backgroundColor: colors.LIGHT_GRAY,
        },
        thead: {
          borderBottomWidth: 0.5,
          borderColor: colors.LIGHT_GRAY,
        },
        th: {
          fontFamily: fonts.APP_FONT_BOLD,
          padding: sizes.PADDING * 0.5,
          color: colors.TEXT,
        },
        td: {
          padding: sizes.PADDING * 0.5,
          borderRightWidth: 1,
          borderColor: colors.LIGHT_GRAY,
        },
        tr: {
          borderBottomWidth: 0.5,
          borderColor: colors.LIGHT_GRAY,
        },
        blockquote: {
          borderLeftWidth: 4,
          borderLeftColor: colors.PRIMARY,
          paddingLeft: sizes.PADDING,
          marginVertical: sizes.PADDING,
          backgroundColor: `${colors.LIGHT_GRAY}15`, // 15% opacity
        },
        hr: {
          backgroundColor: colors.LIGHT_GRAY,
          height: 1,
          marginVertical: sizes.PADDING,
        },
        taskListItem: {
          flexDirection: 'row',
          alignItems: 'center',
        },
        taskListItemText: {
          fontFamily: fonts.APP_FONT_REGULAR,
          fontSize: sizes.FONTSIZE,
          color: colors.TEXT,
          marginLeft: sizes.PADDING / 2,
        },
      }}>
      {children}
    </Markdown>
  );
};

export default StyledMarkdown;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();

  return {
    colors,
    sizes,
  };
};
