import React from 'react';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import { useColors } from '../../constants/color';
import { ActivityIndicator, Text, TouchableOpacity, ViewStyle } from 'react-native';

interface Props {
  title: string;
  onPress?: () => void;
  style?: ViewStyle;
  disabled?: boolean;
  loading?: boolean;
}

const ButtonComponent = ({ title, onPress, style, disabled, loading }: Props) => {
  const sizes = useSizes();
  const colors = useColors();
  const globalStyles = getGlobalStyles(colors, sizes);

  return (
    <TouchableOpacity
      disabled={disabled}
      style={{
        backgroundColor: colors.PRIMARY,
        padding: sizes.PADDING,
        borderRadius: sizes.BORDER_RADIUS,
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        opacity: disabled ? 0.5 : 1,
        ...style,
      }}
      onPress={onPress}>
      {loading ? (
        <ActivityIndicator size="small" color={colors.PRIMARY_TEXT} />
      ) : (
        <Text
          style={{
            ...globalStyles.TEXT_STYLE_BOLD,
            color: colors.PRIMARY_TEXT,
          }}>
          {title}
        </Text>
      )}
    </TouchableOpacity>
  );
};

export default ButtonComponent;
