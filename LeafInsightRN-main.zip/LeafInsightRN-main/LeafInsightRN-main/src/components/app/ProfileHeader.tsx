import { View, Text, Image } from 'react-native';
import React from 'react';
import { useTheme } from '../../constants/size';
import icons from '../../assets/icons';
import images from '../../assets/images';
import fonts from '../../assets/fonts';
import { useUserStore } from '../../store/reducer/user';
import { useSettingsStore } from '../../store/reducer/settings';

const ProfileHeader = () => {
  const theme = useTheme();
  const { user } = useUserStore();
  const { strings } = useSettingsStore();
  return (
    <View
      style={{
        padding: theme.sizes.PADDING,
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      <Image source={images.LOGO} style={{ width: theme.sizes.ICON * 1.5, height: theme.sizes.ICON * 1.5 }} />
      <Text
        style={{
          fontFamily: fonts.APP_FONT_SEMIBOLD,
          fontSize: theme.sizes.FONTSIZE_HIGH,
          marginStart: theme.sizes.PADDING / 2,
          color: theme.colors.GRAY,
        }}>
        {strings.HI}, <Text style={{ color: theme.colors.PRIMARY }}>{user?.name}</Text>
      </Text>
      <Image
        source={icons.PROFILE_PLACEHOLDER}
        style={{
          width: theme.sizes.ICON * 1.5,
          height: theme.sizes.ICON * 1.5,
          borderRadius: theme.sizes.ICON,
          marginStart: 'auto',
        }}
      />
    </View>
  );
};

export default ProfileHeader;
