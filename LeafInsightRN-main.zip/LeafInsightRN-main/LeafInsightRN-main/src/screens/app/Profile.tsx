import React, { useMemo, useState } from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity, Alert } from 'react-native';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import { useNavigation } from '@react-navigation/native';
import { AppStackNavigationProp } from '../../types/navigation.types';
import icons from '../../assets/icons';
import fonts from '../../assets/fonts';
import { clearUser, useUserStore } from '../../store/reducer/user';
import { useDispatch } from 'react-redux';
import useAlert from '../../hooks/useAlert';
import { LocalModal } from '../../components/app/LocaleButton';
import { useSettingsStore } from '../../store/reducer/settings';
const Profile = () => {
  const { styles, colors, sizes } = useStyles();
  const navigation = useNavigation<AppStackNavigationProp>();
  const dispatch = useDispatch();

  const { user } = useUserStore();

  const { showAlert, AlertComponent, hideAlert } = useAlert();
  const [showLangModal, setShowLangModal] = useState(false);
  const { strings } = useSettingsStore();
  const handleLogout = () => {
    showAlert({
      heading: strings.LOGOUT,
      message: strings.LOGOUT_MESSAGE,
      okText: strings.LOGOUT,
      noText: strings.CANCEL,
      onOkPress: () => {
        dispatch(clearUser());
      },
      onNoPress: () => {
        hideAlert();
      },
    });
  };

  const { isRTL } = useSettingsStore();

  return (
    <View style={styles.container}>
      <View style={styles.profileContainer}>
        <Image source={icons.PROFILE_PLACEHOLDER} style={styles.profileImage} />
        <View style={{}}>
          <Text style={styles.userName}>{user?.name}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
        </View>
        {/* <TouchableOpacity
          style={{
            marginStart: 'auto',
            marginEnd: sizes.PADDING,
          }}
          onPress={handleEditProfile}>
          <Image source={icons.EDIT} style={styles.editIcon} />
        </TouchableOpacity> */}
      </View>
      <AlertComponent />

      <View style={styles.actionsContainer}>
        {[
          {
            icon: icons.LANGUAGE,
            label: strings.LANGUAGE,
            onPress: () => {
              setShowLangModal(true);
            },
          },
          {
            icon: icons.ABOUT_US,
            label: strings.ABOUT_US,
            onPress: () => {
              navigation.navigate('DynamicView', {
                title: strings.ABOUT_US,
                url: 'about-us',
              });
            },
          },
          {
            icon: icons.TERMS_AND_CONDITIONS,
            label: strings.TERMS_AND_CONDITIONS,
            onPress: () => {
              navigation.navigate('DynamicView', {
                title: strings.TERMS_AND_CONDITIONS,
                url: 'terms-and-conditions',
              });
            },
          },
        ].map((item, index) => (
          <TouchableOpacity activeOpacity={0.7} style={styles.option} key={index} onPress={item.onPress}>
            <Image source={item.icon} style={styles.optionIcon} />
            <Text style={styles.optionLabel}>{item.label}</Text>
            <Image
              source={icons.ARROW_LEFT}
              style={[
                styles.arrowIcon,
                {
                  transform: [
                    {
                      rotate: isRTL ? '0deg' : '180deg',
                    },
                  ],
                },
              ]}
            />
          </TouchableOpacity>
        ))}

        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Text style={styles.logoutText}>{strings.LOGOUT}</Text>
        </TouchableOpacity>
      </View>
      <LocalModal isVisible={showLangModal} setIsVisible={setShowLangModal} />
    </View>
  );
};

export default Profile;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
          paddingTop: sizes.PADDING,
        },
        header: {
          padding: sizes.PADDING,
          paddingTop: sizes.PADDING * 2,
          alignItems: 'center',
          justifyContent: 'center',
        },
        headerTitle: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
          color: colors.PRIMARY,
        },
        profileContainer: {
          alignItems: 'center',
          paddingVertical: sizes.PADDING * 2,
          paddingHorizontal: sizes.PADDING,
          gap: sizes.PADDING,
          flexDirection: 'row',
        },
        profileImage: {
          width: sizes.WIDTH * 0.2,
          height: sizes.WIDTH * 0.2,
          borderRadius: sizes.WIDTH,
        },
        userName: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
          color: 'black',
        },
        userEmail: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.FONTSIZE,
          color: colors.GRAY,
        },
        actionsContainer: {
          padding: sizes.PADDING,
          paddingVertical: sizes.PADDING * 2,
          marginTop: sizes.PADDING,
          flex: 1,
          backgroundColor: colors.BACKGROUND,
        },

        logoutButton: {
          marginTop: 'auto',
          padding: sizes.PADDING,
          alignItems: 'center',
          justifyContent: 'center',
          borderRadius: sizes.BORDER_RADIUS,
          borderWidth: 1,
          borderColor: colors.RED,
        },
        logoutText: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE,
          color: colors.RED,
        },
        option: {
          flexDirection: 'row',
          alignItems: 'center',
          gap: sizes.PADDING,
          marginBottom: sizes.PADDING * 2,
        },
        optionIcon: {
          width: sizes.ICON,
          height: sizes.ICON,
          tintColor: colors.GRAY,
        },
        arrowIcon: {
          width: sizes.WIDTH * 0.05,
          height: sizes.WIDTH * 0.05,
          tintColor: colors.GRAY,
          transform: [{ rotate: '180deg' }],
          marginStart: 'auto',
        },
        optionLabel: {
          fontFamily: fonts.APP_FONT_SEMIBOLD,
          fontSize: sizes.FONTSIZE,
          color: colors.GRAY,
        },
        editIcon: {
          width: sizes.WIDTH * 0.05,
          height: sizes.WIDTH * 0.05,
          tintColor: colors.BLACK,
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
