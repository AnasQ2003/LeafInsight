import React, { useMemo, useState } from 'react';
import { StyleSheet, View, Image } from 'react-native';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import { useNavigation, useRoute, RouteProp } from '@react-navigation/native';
import { AppStackNavigationProp, AppStackParamList } from '../../types/navigation.types';
import BackButton from '../../components/global/BackButton';
import ButtonComponent from '../../components/app/ButtonComponent';
import DropDownSelect from '../../components/global/DropDownSelect';
import { _createScan } from '../../utils/api-helper';
import { useUserStore } from '../../store/reducer/user';
import { useSettingsStore } from '../../store/reducer/settings';
type PreviewScreenRouteProp = RouteProp<AppStackParamList, 'PreviewScreen'>;

const PreviewScreen = () => {
  const { styles, colors, sizes } = useStyles();
  const navigation = useNavigation<AppStackNavigationProp>();
  const route = useRoute<PreviewScreenRouteProp>();
  const { photo } = route.params;

  const { user } = useUserStore();

  const [loading, setLoading] = useState(false);
  const { strings } = useSettingsStore();

  const onConfirm = () => {
    if (loading) return;
    setLoading(true);
    _createScan(photo, user?.token!)
      .then(res => {
        if (res) {
          navigation.replace('DynamicView', {
            md: res.data.mdBlog,
            title: res.data.diseaseName,
          });
        }
      })
      .finally(() => setLoading(false));
  };

  return (
    <View style={styles.container}>
      <BackButton onPress={() => navigation.goBack()} title={strings.RETAKE} />
      <View style={styles.previewContainer}>
        <Image source={{ uri: photo }} style={styles.previewImage} />
        {/* <DropDownSelect
          containerStyle={{
            marginTop: sizes.PADDING,
          }}
          placeholder="Select Leaf Type"
          onSelect={() => {}}
          options={[
            { label: 'Leaf Type 1', value: 'leaf_type_1' },
            { label: 'Leaf Type 2', value: 'leaf_type_2' },
            { label: 'Leaf Type 3', value: 'leaf_type_3' },
          ]}
        /> */}
        <ButtonComponent
          title={strings.CONFIRM}
          onPress={onConfirm}
          style={{ marginTop: sizes.PADDING }}
          loading={loading}
        />
      </View>
    </View>
  );
};

export default PreviewScreen;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
        },
        previewContainer: {
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          padding: sizes.WIDTH * 0.05,
        },
        previewImage: {
          width: '100%',
          height: '80%',
          borderRadius: 10,
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
