import React, { useMemo } from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import StatusBarComponent from '../../components/global/StatusBarComponent';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import images from '../../assets/images';
import { useNavigation } from '@react-navigation/native';
import InputComponent from '../../components/global/InputComponent';
import ButtonComponent from '../../components/app/ButtonComponent';
import { Formik } from 'formik';
import * as Yup from 'yup';
import BackButton from '../../components/global/BackButton';
import icons from '../../assets/icons';

const EditProfileScreen = () => {
  const { styles, colors, sizes } = useStyles();
  const navigation = useNavigation();

  const initialValues = {
    fullName: 'John Doe',
    email: 'john.doe@example.com',
    phone: '+1 123-456-7890',
  };

  const validationSchema = Yup.object().shape({
    fullName: Yup.string().required('*Required'),
    email: Yup.string().email('Invalid email').required('*Required'),
    phone: Yup.string(),
  });

  const handleSubmit = (values: { fullName: string; email: string; phone: string }) => {
    console.log('Profile updated', values);
    navigation.goBack();
  };

  const handleChoosePhoto = () => {
    // Logic to pick image from gallery
    console.log('Choose photo pressed');
  };

  return (
    <View style={styles.container}>
      <BackButton onPress={() => navigation.goBack()} title="Back" />

      <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
        {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
          <View style={styles.formContainer}>
            <View style={styles.profileImageContainer}>
              <Image source={icons.PROFILE_PLACEHOLDER} style={styles.profileImage} />
            </View>

            <InputComponent
              containerStyle={styles.inputContainer}
              error={touched.fullName && errors.fullName}
              fieldProps={{
                placeholder: 'Enter your full name',
                value: values.fullName,
                onChangeText: handleChange('fullName'),
                onBlur: handleBlur('fullName'),
              }}
            />

            <InputComponent
              containerStyle={styles.inputContainer}
              error={touched.email && errors.email}
              fieldProps={{
                placeholder: 'Enter your email',
                keyboardType: 'email-address',
                autoCapitalize: 'none',
                value: values.email,
                onChangeText: handleChange('email'),
                onBlur: handleBlur('email'),
              }}
            />

            <InputComponent
              containerStyle={styles.inputContainer}
              error={touched.phone && errors.phone}
              fieldProps={{
                placeholder: 'Enter your phone number',
                keyboardType: 'phone-pad',
                value: values.phone,
                onChangeText: handleChange('phone'),
                onBlur: handleBlur('phone'),
              }}
            />

            <ButtonComponent title="Save Changes" style={styles.saveButton} onPress={handleSubmit} />
          </View>
        )}
      </Formik>
    </View>
  );
};

export default EditProfileScreen;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
          paddingTop: sizes.PADDING * 3,
        },
        header: {
          alignItems: 'center',
          marginTop: sizes.PADDING * 2,
          marginBottom: sizes.PADDING,
        },
        headerTitle: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
          color: colors.PRIMARY,
        },
        formContainer: {
          padding: sizes.PADDING,
        },
        profileImageContainer: {
          alignItems: 'center',
          marginBottom: sizes.PADDING * 2,
        },
        profileImage: {
          width: sizes.WIDTH * 0.25,
          height: sizes.WIDTH * 0.25,
          borderRadius: (sizes.WIDTH * 0.25) / 2,
        },
        editImageButton: {
          marginTop: sizes.PADDING,
        },
        editImageText: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.FONTSIZE,
          color: colors.PRIMARY,
        },
        inputContainer: {
          marginTop: sizes.PADDING,
        },
        saveButton: {
          marginTop: sizes.PADDING * 2,
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
