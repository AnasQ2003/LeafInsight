import React, { useEffect, useMemo, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import StatusBarComponent from '../../components/global/StatusBarComponent';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import ProfileHeader from '../../components/app/ProfileHeader';
import fonts from '../../assets/fonts';
import Blogs from '../../components/home/Blogs';
import History from '../../components/home/History';
import { _getBlogs, _getScans } from '../../utils/api-helper';
import { useSettingsStore } from '../../store/reducer/settings';
const Index = ({}) => {
  const { styles, colors } = useStyles();
  const [activeTab, setActiveTab] = useState<'blog' | 'history'>('blog');

  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [blogsPage, setBlogsPage] = useState(1);
  const [blogsLastPage, setBlogsLastPage] = useState(false);

  const [scans, setScans] = useState<Scan[]>([]);
  const [scansPage, setScansPage] = useState(1);
  const [scansLastPage, setScansLastPage] = useState(false);

  const { strings } = useSettingsStore();

  return (
    <View style={styles.container}>
      <ProfileHeader />
      {/* Tab Selector */}
      <View style={styles.tabSelector}>
        <TouchableOpacity
          style={[
            styles.tabSelectorView,
            {
              borderBottomWidth: 2,
              paddingBottom: 7,
              borderColor: activeTab === 'blog' ? colors.PRIMARY : 'transparent',
            },
          ]}
          onPress={() => setActiveTab('blog')}>
          <Text
            style={[
              styles.tabSelectorText,
              {
                color: activeTab === 'blog' ? colors.PRIMARY : colors.GRAY,
                fontFamily: activeTab === 'blog' ? fonts.APP_FONT_SEMIBOLD : fonts.APP_FONT_REGULAR,
              },
            ]}>
            {strings.BLOG}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tabSelectorView,
            {
              borderBottomWidth: 2,
              paddingBottom: 7,
              borderColor: activeTab === 'history' ? colors.PRIMARY : 'transparent',
            },
          ]}
          onPress={() => setActiveTab('history')}>
          <Text
            style={[
              styles.tabSelectorText,
              {
                color: activeTab === 'history' ? colors.PRIMARY : colors.GRAY,
                fontFamily: activeTab === 'history' ? fonts.APP_FONT_SEMIBOLD : fonts.APP_FONT_REGULAR,
              },
            ]}>
            {strings.HISTORY}
          </Text>
        </TouchableOpacity>
      </View>
      {activeTab === 'blog' && (
        <Blogs
          blogs={blogs}
          blogsLastPage={blogsLastPage}
          setBlogsLastPage={setBlogsLastPage}
          setBlogs={setBlogs}
          blogsPage={blogsPage}
          setBlogsPage={setBlogsPage}
        />
      )}
      {activeTab === 'history' && (
        <History
          scans={scans}
          setScans={setScans}
          scansLastPage={scansLastPage}
          setScansLastPage={setScansLastPage}
          scansPage={scansPage}
          setScansPage={setScansPage}
        />
      )}
    </View>
  );
};

export default Index;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
        },
        contStyle: {
          marginTop: sizes.HEIGHT * 0.04,
          paddingBottom: sizes.WIDTH * 0.04,
        },
        txt1: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.WIDTH * 0.033,
          color: 'black',
        },
        tabSelector: {
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingHorizontal: sizes.PADDING,
          gap: sizes.PADDING,
        },
        tabSelectorText: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.WIDTH * 0.045,
          color: colors.GRAY,
        },

        tabSelectorView: {
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
