import React, { useMemo } from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import { useNavigation } from '@react-navigation/native';
import { AppStackNavigationProp } from '../../types/navigation.types';
import ProfileHeader from '../../components/app/ProfileHeader';
import { handleGallerySelect } from '../../utils';
import ButtonComponent from '../../components/app/ButtonComponent';
import { useSettingsStore } from '../../store/reducer/settings';

const NewScanScreen = () => {
  const { styles, colors } = useStyles();
  const navigation = useNavigation<AppStackNavigationProp>();

  const handleSelect = () => {
    handleGallerySelect(url => {
      navigation.navigate('PreviewScreen', { photo: url });
    });
  };

  const handleCameraSelect = () => {
    navigation.navigate('CameraScreen');
  };

  const { strings } = useSettingsStore();

  return (
    <View style={styles.container}>
      <ProfileHeader />
      <View style={styles.optionsContainer}>
        <ButtonComponent title={strings.SELECT_FROM_GALLERY} onPress={handleSelect} />
        <ButtonComponent title={strings.USE_CAMERA} onPress={handleCameraSelect} />
      </View>
    </View>
  );
};

export default NewScanScreen;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
        },
        headerText: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.WIDTH * 0.06,
          fontWeight: 'bold',
          marginTop: sizes.HEIGHT * 0.02,
          marginBottom: sizes.HEIGHT * 0.04,
          textAlign: 'center',
        },
        optionsContainer: {
          flex: 1,
          padding: sizes.PADDING,
          gap: sizes.PADDING,
        },

        previewContainer: {
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        },
        previewImage: {
          width: '100%',
          height: '60%',
          borderRadius: 10,
          marginBottom: sizes.HEIGHT * 0.03,
        },
        buttonRow: {
          flexDirection: 'row',
          justifyContent: 'space-around',
          width: '100%',
          gap: sizes.WIDTH * 0.03,
        },
        contStyle: {
          marginTop: sizes.HEIGHT * 0.04,
          paddingBottom: sizes.WIDTH * 0.04,
        },
        txt1: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.WIDTH * 0.033,
          color: 'black',
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
