import { View, Text, ScrollView, StyleSheet, ActivityIndicator } from 'react-native';
import React, { useEffect, useMemo, useState } from 'react';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import BackButton from '../../components/global/BackButton';
import { useNavigation, useRoute } from '@react-navigation/native';
import { AppStackNavigationProp } from '../../types/navigation.types';
import StyledMarkdown from '../../components/app/StyledMarkdown';
import { _getDynamicPage } from '../../utils/api-helper';
import { useSettingsStore } from '../../store/reducer/settings';

interface DynamicViewParams {
  title?: string;
  md?: string;
  url?: string;
}

const useDynamicView = () => {
  const route = useRoute();
  const params = route.params as DynamicViewParams;
  const { title, md, url } = params || { title: 'Content', md: '', url: '' };

  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState<DynamicPage | null>(null);

  useEffect(() => {
    if (url && !isLoading) {
      setIsLoading(true);
      _getDynamicPage(url).then(res => {
        if (res?.id) {
          setData(res);
        } else {
          setData({
            id: 0,
            title: url,
            md: url,
            createdAt: '',
            url: url,
          });
        }
        setIsLoading(false);
      });
    }
  }, [url]);

  return {
    title: data?.title || title,
    md: data?.md || md,
    url: data?.url || url,
    isLoading,
  };
};

const DynamicView = () => {
  const { title, md, url, isLoading } = useDynamicView();
  const { styles, sizes, colors } = useStyles();

  const navigation = useNavigation<AppStackNavigationProp>();
  const { strings } = useSettingsStore();

  return (
    <View style={styles.container}>
      <BackButton onPress={() => navigation.goBack()} title={strings.BACK} containerStyle={styles.backButton} />
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.PRIMARY} />
        </View>
      ) : (
        <>
          <Text style={styles.title}>{title}</Text>
          <ScrollView
            style={styles.scrollView}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingBottom: sizes.PADDING * 2 }}>
            <StyledMarkdown>{md || ''}</StyledMarkdown>
          </ScrollView>
        </>
      )}
    </View>
  );
};

export default DynamicView;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
          padding: sizes.PADDING,
          paddingTop: sizes.PADDING * 3,
        },
        backButton: {
          position: 'absolute',
          top: sizes.PADDING * 2,
          left: sizes.PADDING,
          zIndex: 1,
        },
        title: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
          textAlign: 'center',
          marginTop: sizes.PADDING * 2,
          marginBottom: sizes.PADDING,
          position: 'absolute',
          alignSelf: 'center',
        },
        scrollView: {
          flex: 1,
          marginTop: sizes.PADDING * 2,
        },
        loadingContainer: {
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    styles,
    sizes,
    colors,
  };
};
