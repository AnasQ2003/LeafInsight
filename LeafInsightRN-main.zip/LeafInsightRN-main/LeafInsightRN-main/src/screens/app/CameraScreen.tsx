import React, { useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Alert } from 'react-native';
import { Camera, useCameraDevice, CameraRuntimeError } from 'react-native-vision-camera';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import { useNavigation } from '@react-navigation/native';
import { AppStackNavigationProp } from '../../types/navigation.types';
import BackButton from '../../components/global/BackButton';
import ButtonComponent from '../../components/app/ButtonComponent';
import { useSettingsStore } from '../../store/reducer/settings';
const CameraScreen = () => {
  const { styles, colors, sizes } = useStyles();
  const navigation = useNavigation<AppStackNavigationProp>();
  const [hasPermission, setHasPermission] = useState(false);
  const cameraRef = useRef<Camera>(null);
  const device = useCameraDevice('back');

  useEffect(() => {
    (async () => {
      const cameraPermission = await Camera.requestCameraPermission();
      setHasPermission(cameraPermission === 'granted');
    })();
  }, []);

  const { strings } = useSettingsStore();

  const onCapture = async () => {
    try {
      if (cameraRef.current) {
        const photo = await cameraRef.current.takePhoto({
          flash: 'off',
        });
        const photoUri = `file://${photo.path}`;
        navigation.navigate('PreviewScreen', { photo: photoUri });
      }
    } catch (error) {
      if (error instanceof CameraRuntimeError) {
        console.error('Camera error:', error.message);
      } else {
        console.error('Unexpected error:', error);
      }
    }
  };

  if (!hasPermission) {
    return (
      <View style={styles.container}>
        <BackButton onPress={() => navigation.goBack()} title="Back" />
        <View style={styles.centerContent}>
          <Text style={styles.text}>{strings.CAMERA_PERMISSION_REQUIRED}</Text>
          <ButtonComponent
            title={strings.REQUEST_PERMISSION}
            onPress={() => Camera.requestCameraPermission()}
            style={{
              marginTop: sizes.PADDING,
            }}
          />
        </View>
      </View>
    );
  }

  if (!device) {
    return (
      <View style={styles.container}>
        <BackButton onPress={() => navigation.goBack()} title="Back" />
        <View style={styles.centerContent}>
          <Text style={styles.text}>{strings.NO_CAMERA_DEVICE_FOUND}</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.cameraContainer}>
        <Camera ref={cameraRef} style={styles.camera} device={device} isActive={true} photo={true} />
        <View style={styles.controlsContainer}>
          <TouchableOpacity style={styles.captureButton} onPress={onCapture}>
            <View style={styles.captureButtonInner} />
          </TouchableOpacity>
        </View>
      </View>
      <BackButton onPress={() => navigation.goBack()} title={strings.BACK} color={colors.WHITE} />
    </View>
  );
};

export default CameraScreen;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
        },

        centerContent: {
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          padding: sizes.WIDTH * 0.05,
        },
        text: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.WIDTH * 0.04,
          textAlign: 'center',
          marginBottom: sizes.HEIGHT * 0.02,
        },
        cameraContainer: {
          flex: 1,
          overflow: 'hidden',
        },
        camera: {
          flex: 1,
        },
        controlsContainer: {
          position: 'absolute',
          bottom: 30,
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',
        },
        captureButton: {
          width: 70,
          height: 70,
          borderRadius: 35,
          backgroundColor: 'rgba(255, 255, 255, 0.3)',
          justifyContent: 'center',
          alignItems: 'center',
        },
        captureButtonInner: {
          width: 60,
          height: 60,
          borderRadius: 30,
          backgroundColor: 'white',
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
