import React, { useMemo } from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import images from '../../assets/images';
import InputComponent from '../../components/global/InputComponent';
import ButtonComponent from '../../components/app/ButtonComponent';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { useNavigation } from '@react-navigation/native';
import { AuthStackNavigationProp } from '../../types/navigation.types';
import LocaleButton from '../../components/app/LocaleButton';
import BackButton from '../../components/global/BackButton';
import { useSettingsStore } from '../../store/reducer/settings';
const ForgotPasswordScreen = () => {
  const { styles, colors, sizes } = useStyles();
  const navigation = useNavigation<AuthStackNavigationProp>();

  const { strings } = useSettingsStore();

  return (
    <View style={styles.container}>
      <LocaleButton containerStyle={styles.localeButton} />
      <BackButton onPress={() => navigation.navigate('Login')} title={strings.LOGIN} />
      <Image source={images.LOGO} style={styles.logo} />
      <Text style={styles.txt1}>{strings.FORGOT_PASSWORD}</Text>
      <Text style={styles.txt2}>{strings.FORGOT_PASSWORD_MESSAGE}</Text>

      <Formik
        validationSchema={Yup.object().shape({
          email: Yup.string().email('Invalid email').required('*Required'),
        })}
        initialValues={{ email: '' }}
        onSubmit={() => {}}>
        {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
          <>
            <InputComponent
              containerStyle={{
                marginTop: sizes.PADDING * 2,
              }}
              error={touched.email && errors.email}
              fieldProps={{
                placeholder: strings.EMAIL,
                keyboardType: 'email-address',
                autoCapitalize: 'none',
                value: values.email,
                onChangeText: handleChange('email'),
                onBlur: handleBlur('email'),
              }}
            />

            <ButtonComponent
              title={strings.SEND_RESET_LINK}
              style={{ marginTop: sizes.PADDING * 2 }}
              onPress={handleSubmit}
            />
          </>
        )}
      </Formik>
    </View>
  );
};

export default ForgotPasswordScreen;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
          alignItems: 'center',
          justifyContent: 'center',
          padding: sizes.PADDING,
        },
        localeButton: {
          position: 'absolute',
          top: sizes.PADDING,
          right: sizes.PADDING,
        },
        backButton: {
          position: 'absolute',
          top: sizes.PADDING * 2,
          left: sizes.PADDING * 2,
        },
        backButtonText: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE,
          color: colors.PRIMARY,
        },
        logo: {
          width: sizes.WIDTH * 0.4,
          height: sizes.WIDTH * 0.4,
        },
        txt1: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
          color: 'black',
          marginBottom: sizes.PADDING,
        },
        txt2: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.FONTSIZE,
          color: 'black',
          textAlign: 'center',
          marginBottom: sizes.PADDING,
          maxWidth: sizes.WIDTH * 0.8,
        },
        backToLogin: {
          marginTop: sizes.PADDING * 3,
        },
        txt4: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE,
          color: colors.PRIMARY,
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
