import React, { useMemo } from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import StatusBarComponent from '../../components/global/StatusBarComponent';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import images from '../../assets/images';
import InputComponent from '../../components/global/InputComponent';
import ButtonComponent from '../../components/app/ButtonComponent';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { useNavigation } from '@react-navigation/native';
import { AuthStackNavigationProp } from '../../types/navigation.types';
import LocaleButton from '../../components/app/LocaleButton';
import BackButton from '../../components/global/BackButton';
import useCenterLoader from '../../hooks/useCenterLoader';
import api from '../../utils/api';
import apiEndPoints from '../../constants/apiEndPoints';
import notify from '../../utils/notify';
import { useDispatch } from 'react-redux';
import { setUser } from '../../store/reducer/user';
import { useSettingsStore } from '../../store/reducer/settings';
interface SignUpForm {
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
}

const SignUpScreen = () => {
  const { styles, sizes } = useStyles();
  const navigation = useNavigation<AuthStackNavigationProp>();
  const { loading, setLoading, LoaderComponent } = useCenterLoader();
  const dispatch = useDispatch();
  const { strings } = useSettingsStore();

  const handleSignUp = (values: SignUpForm) => {
    if (loading) return;
    setLoading(true);
    api
      .post<{
        user: User;
        jwt: string;
      }>(apiEndPoints.REGISTER, {
        username: values.email,
        name: values.fullName,
        email: values.email,
        password: values.password,
      })
      .then(res => {
        if (res.failed) {
          notify.error(res.message);
          return;
        }

        dispatch(
          setUser({
            ...(res.data?.user as any),
            token: res?.data?.jwt || '',
          }),
        );

        notify.success('Account created successfully');
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <View style={styles.container}>
      <LoaderComponent />
      <LocaleButton containerStyle={styles.localeButton} />
      <BackButton onPress={() => navigation.navigate('Login')} title={strings.LOGIN} />
      <Image source={images.LOGO} style={styles.logo} />
      <Text style={styles.txt1}>{strings.CREATE_ACCOUNT}</Text>

      <Formik
        validationSchema={Yup.object().shape({
          fullName: Yup.string().required(strings.REQUIRED),
          email: Yup.string().email(strings.INVALID_EMAIL).required(strings.REQUIRED),
          password: Yup.string().min(8, strings.MIN_8_CHARACTERS).required(strings.REQUIRED),
          confirmPassword: Yup.string()
            .oneOf([Yup.ref('password')], strings.PASSWORDS_MUST_MATCH)
            .required(strings.REQUIRED),
        })}
        initialValues={{ fullName: '', email: '', password: '', confirmPassword: '' }}
        onSubmit={handleSignUp}>
        {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
          <>
            <InputComponent
              error={touched.fullName && errors.fullName}
              fieldProps={{
                placeholder: strings.FULL_NAME,
                keyboardType: 'default',
                value: values.fullName,
                onChangeText: handleChange('fullName'),
                onBlur: handleBlur('fullName'),
              }}
            />
            <InputComponent
              containerStyle={{
                marginTop: sizes.PADDING,
              }}
              error={touched.email && errors.email}
              fieldProps={{
                placeholder: strings.EMAIL,
                keyboardType: 'email-address',
                autoCapitalize: 'none',
                value: values.email,
                onChangeText: handleChange('email'),
                onBlur: handleBlur('email'),
              }}
            />
            <InputComponent
              containerStyle={{
                marginTop: sizes.PADDING,
              }}
              error={touched.password && errors.password}
              fieldProps={{
                placeholder: strings.PASSWORD,
                keyboardType: 'default',
                secureTextEntry: true,
                value: values.password,
                onChangeText: handleChange('password'),
                onBlur: handleBlur('password'),
              }}
            />
            <InputComponent
              containerStyle={{
                marginTop: sizes.PADDING,
              }}
              error={touched.confirmPassword && errors.confirmPassword}
              fieldProps={{
                placeholder: strings.CONFIRM_PASSWORD,
                keyboardType: 'default',
                secureTextEntry: true,
                value: values.confirmPassword,
                onChangeText: handleChange('confirmPassword'),
                onBlur: handleBlur('confirmPassword'),
              }}
            />

            <ButtonComponent title={strings.SIGN_UP} style={{ marginTop: sizes.PADDING * 2 }} onPress={handleSubmit} />
          </>
        )}
      </Formik>

      <View style={styles.login}>
        <Text style={styles.txt3}>{strings.ALREADY_HAVE_AN_ACCOUNT}</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Login')}>
          <Text style={styles.txt4}>{strings.LOGIN}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default SignUpScreen;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
          alignItems: 'center',
          justifyContent: 'center',
          padding: sizes.PADDING,
        },
        localeButton: {
          position: 'absolute',
          top: sizes.PADDING,
          right: sizes.PADDING,
        },
        backButton: {
          position: 'absolute',
          top: sizes.PADDING * 2,
          left: sizes.PADDING * 2,
        },
        backButtonText: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE,
          color: colors.PRIMARY,
        },
        logo: {
          width: sizes.WIDTH * 0.4,
          height: sizes.WIDTH * 0.4,
        },
        txt1: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
          color: 'black',
          marginBottom: sizes.PADDING * 2,
        },
        login: {
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: sizes.PADDING * 3,
        },
        txt3: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.FONTSIZE,
          color: 'black',
        },
        txt4: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE,
          color: colors.PRIMARY,
          marginStart: 2,
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
