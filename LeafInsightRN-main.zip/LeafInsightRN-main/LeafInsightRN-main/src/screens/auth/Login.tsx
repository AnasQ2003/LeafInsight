import React, { useMemo, useState } from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import StatusBarComponent from '../../components/global/StatusBarComponent';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import { getGlobalStyles } from '../../constants/globalStyles';
import images from '../../assets/images';
import InputComponent from '../../components/global/InputComponent';
import ButtonComponent from '../../components/app/ButtonComponent';
import { Formik } from 'formik';
import * as Yup from 'yup';
import { useNavigation } from '@react-navigation/native';
import { AuthStackNavigationProp } from '../../types/navigation.types';
import LocaleButton from '../../components/app/LocaleButton';
import { useDispatch } from 'react-redux';
import { setUser } from '../../store/reducer/user';
import api from '../../utils/api';
import apiEndPoints from '../../constants/apiEndPoints';
import notify from '../../utils/notify';
import useCenterLoader from '../../hooks/useCenterLoader';
import CenterModal from '../../components/global/CenterModal';
import { useSettingsStore } from '../../store/reducer/settings';
interface LoginForm {
  email: string;
  password: string;
}

const LoginScreen = () => {
  const { styles, colors, sizes } = useStyles();
  const navigation = useNavigation<AuthStackNavigationProp>();
  const dispatch = useDispatch();

  const { loading, setLoading, LoaderComponent } = useCenterLoader();

  const handleLogin = (values: LoginForm) => {
    if (loading) return;
    setLoading(true);
    api
      .post<{
        user: User;
        jwt: string;
      }>(apiEndPoints.LOGIN, {
        identifier: values.email,
        password: values.password,
      })
      .then(res => {
        if (res.failed) {
          notify.error(res.message);
          return;
        }

        dispatch(
          setUser({
            ...(res.data?.user as any),
            token: res?.data?.jwt || '',
          }),
        );
      })
      .finally(() => {
        setLoading(false);
      });
  };

  const { strings } = useSettingsStore();

  return (
    <View style={styles.container}>
      <LoaderComponent />
      <LocaleButton containerStyle={styles.localeButton} />
      <Image source={images.LOGO} style={styles.logo} />
      <Text style={styles.txt1}>{strings.WELCOME_BACK}</Text>

      <Formik
        validationSchema={Yup.object().shape({
          email: Yup.string().email(strings.INVALID_EMAIL).required(strings.REQUIRED),
          password: Yup.string().min(8, strings.MIN_8_CHARACTERS).required(strings.REQUIRED),
        })}
        initialValues={{ email: '', password: '' }}
        onSubmit={handleLogin}>
        {({ handleChange, handleBlur, handleSubmit, values, errors, touched }) => (
          <>
            <InputComponent
              error={touched.email && errors.email}
              fieldProps={{
                placeholder: strings.EMAIL,
                keyboardType: 'email-address',
                autoCapitalize: 'none',
                value: values.email,
                onChangeText: handleChange('email'),
                onBlur: handleBlur('email'),
              }}
            />
            <InputComponent
              containerStyle={{
                marginTop: sizes.PADDING,
              }}
              error={touched.password && errors.password}
              fieldProps={{
                placeholder: strings.PASSWORD,
                keyboardType: 'default',
                secureTextEntry: true,
                value: values.password,
                onChangeText: handleChange('password'),
                onBlur: handleBlur('password'),
              }}
            />

            <TouchableOpacity style={styles.forgotPassword} onPress={() => navigation.navigate('ForgotPassword')}>
              <Text style={styles.txt2}>{strings.FORGOT_PASSWORD}</Text>
            </TouchableOpacity>

            <ButtonComponent title={strings.LOGIN} style={{ marginTop: sizes.PADDING * 1.5 }} onPress={handleSubmit} />
          </>
        )}
      </Formik>

      <View style={styles.signUp}>
        <Text style={styles.txt3}>{strings.DONT_HAVE_AN_ACCOUNT}</Text>
        <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
          <Text style={styles.txt4}>{strings.SIGN_UP}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default LoginScreen;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();
  const globalStyles = getGlobalStyles(colors, sizes);

  const styles = useMemo(
    () =>
      StyleSheet.create({
        container: {
          flex: 1,
          backgroundColor: colors.PRIMARY_BACKGROUND,
          alignItems: 'center',
          justifyContent: 'center',
          padding: sizes.PADDING,
        },

        logo: {
          width: sizes.WIDTH * 0.4,
          height: sizes.WIDTH * 0.4,
        },
        localeButton: {
          position: 'absolute',
          top: sizes.PADDING,
          right: sizes.PADDING,
        },
        txt1: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE_HIGH,
          color: 'black',
          marginBottom: sizes.PADDING * 2,
        },
        txt2: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.FONTSIZE,
          color: colors.PRIMARY,
        },
        forgotPassword: {
          alignSelf: 'flex-end',
          marginTop: sizes.PADDING / 2,
        },
        signUp: {
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: sizes.PADDING * 3,
        },
        txt3: {
          ...globalStyles.TEXT_STYLE,
          fontSize: sizes.FONTSIZE,
          color: 'black',
        },
        txt4: {
          ...globalStyles.TEXT_STYLE_BOLD,
          fontSize: sizes.FONTSIZE,
          color: colors.PRIMARY,
          marginStart: 2,
        },
      }),
    [colors, sizes, globalStyles],
  );

  return {
    colors,
    sizes,
    styles,
  };
};
