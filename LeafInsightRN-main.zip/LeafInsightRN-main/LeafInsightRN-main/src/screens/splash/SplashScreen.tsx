import React, { useEffect } from 'react';
import { StyleSheet, View, Image, Animated } from 'react-native';
import { useColors } from '../../constants/color';
import { useSizes } from '../../constants/size';
import images from '../../assets/images';

const SplashScreen = () => {
  const { styles } = useStyles();

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.logoContainer, { opacity: 1 }]}>
        <Image source={images.LOGO} style={styles.logo} resizeMode="contain" />
      </Animated.View>
    </View>
  );
};

export default SplashScreen;

const useStyles = () => {
  const colors = useColors();
  const sizes = useSizes();

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.PRIMARY_BACKGROUND,
      alignItems: 'center',
      justifyContent: 'center',
    },
    logoContainer: {
      alignItems: 'center',
      justifyContent: 'center',
    },
    logo: {
      width: sizes.WIDTH * 0.4,
      height: sizes.WIDTH * 0.4,
    },
  });

  return {
    styles,
  };
};
