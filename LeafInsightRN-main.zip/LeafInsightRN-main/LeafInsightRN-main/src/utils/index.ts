import { Alert } from 'react-native';
import { ImagePickerResponse, launchImageLibrary } from 'react-native-image-picker';
import notify from './notify';
import apiEndPoints from '../constants/apiEndPoints';
import { store } from '../store/store';

export const getTimeAgo = (date: string) => {
  const now = new Date();
  const then = new Date(date);
  const diff = now.getTime() - then.getTime();

  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (seconds < 60) {
    return 'just now';
  } else if (minutes < 60) {
    return `${minutes} minutes ago`;
  } else if (hours < 24) {
    return `${hours} hours ago`;
  } else if (days < 7) {
    return `${days} days ago`;
  } else if (days < 30) {
    const weeks = Math.floor(days / 7);
    return `${weeks} weeks ago`;
  } else if (days < 365) {
    const months = Math.floor(days / 30);
    return `${months} months ago`;
  } else {
    const years = Math.floor(days / 365);
    return `${years} years ago`;
  }
};

export const handleGallerySelect = (callback: (imageUri: string) => void) => {
  launchImageLibrary(
    {
      mediaType: 'photo',
      includeBase64: false,
      maxHeight: 2000,
      maxWidth: 2000,
    },
    (response: ImagePickerResponse) => {
      if (response.didCancel) {
        console.log('User cancelled image picker');
      } else if (response.errorCode) {
        notify.error('There was an error selecting the image.');
      } else if (response.assets && response.assets.length > 0) {
        const imageUri = response.assets[0].uri;
        if (imageUri) {
          callback(imageUri);
        }
      }
    },
  );
};

export const loadImage = (strapiImage: StrapiImage) => {
  if (!strapiImage) return null;
  const image = `${apiEndPoints.BASE_URL}${strapiImage.url}`;
  const thumbnail = `${apiEndPoints.BASE_URL}${strapiImage?.formats?.thumbnail?.url}`;
  return {
    image,
    thumbnail,
    view: () => thumbnail || image,
  };
};

export const getLocale = () => {
  const locale = store.getState().settings.settings.langID;
  return locale;
};
