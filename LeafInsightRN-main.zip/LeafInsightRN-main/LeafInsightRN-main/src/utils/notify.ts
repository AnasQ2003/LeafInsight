import { ToastAndroid } from 'react-native';

const notifyMessage = (message: string) => {
  ToastAndroid.show(message, ToastAndroid.SHORT);
};

const notify = {
  error: (message: string) => {
    notifyMessage(message);
  },
  success: (message: string) => {
    notifyMessage(message);
  },
};

export default notify;
