import api, { getAuthHeader } from './api';
import apiEndPoints from '../constants/apiEndPoints';
import notify from './notify';
import { getLocale } from '.';

export const _getDynamicPage = async (url: string): Promise<DynamicPage | null> => {
  const response = await api.get<{ data: DynamicPage }>(apiEndPoints.DYNAMIC_PAGE(url, getLocale()));
  return response?.data?.data || null;
};

export const _getBlogs = async (page: number) => {
  const response = await api.get<{
    data: Blog[];
    meta: {
      pagination: Pagination;
    };
  }>(apiEndPoints.BLOGS(page, getLocale()));

  return response?.data;
};

export const _getScans = async (page: number, token: string) => {
  const response = await api.get<{
    data: Scan[];
    meta: {
      pagination: Pagination;
    };
  }>(apiEndPoints.GET_SCANS(page), getAuthHeader(token));

  console.log(response);

  return response?.data;
};

export const _createScan = async (imageUrl: string, token: string) => {
  const formData = new FormData();

  const file = {
    uri: imageUrl?.startsWith('file://') ? imageUrl : `file://${imageUrl}`,
    name: 'image.jpg',
    type: 'image/jpeg',
  };

  formData.append('image', file);

  const response = await api.post<{ data: Scan }>(`${apiEndPoints.CREATE_SCAN}?locale=${getLocale()}`, formData, {
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'multipart/form-data',
    },
  });

  if (response.failed) {
    console.log(response);
    notify.error(response.message);
    return null;
  }

  notify.success('Scanned successfully');
  return response?.data;
};
