import { useState } from 'react';
import { Modal, View } from 'react-native';
import { ActivityIndicator } from 'react-native';
import { useColors } from '../constants/color';

const useCenterLoader = () => {
  const [loading, setLoading] = useState(false);
  const colors = useColors();
  return {
    loading,
    setLoading,
    LoaderComponent: () =>
      loading ? (
        <Modal visible={loading} transparent={true} style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.3)' }}>
            <ActivityIndicator size="large" color={colors.PRIMARY} />
          </View>
        </Modal>
      ) : null,
  };
};

export default useCenterLoader;
