import React, { useState } from 'react';
import AlertComponent from '../components/global/AlertComponent';

interface AlertProps {
  message?: string;
  heading?: string;
  onOkPress: () => void;
  onNoPress?: () => void;
  noText?: string;
  okText?: string;
}

const useAlert = () => {
  const [alert, setAlert] = useState<AlertProps | null>();

  const showAlert = (props: AlertProps) => {
    setAlert(props);
  };

  const hideAlert = () => {
    setAlert(null);
  };

  return {
    AlertComponent: () =>
      !!alert?.heading ? (
        <AlertComponent
          isVisible={true}
          headerText={alert.heading}
          text={alert.message}
          noText={alert.noText}
          onNoPress={alert.onNoPress}
          okText={alert.okText}
          onOkPress={alert.onOkPress}
        />
      ) : null,
    showAlert,
    hideAlert,
  };
};

export default useAlert;
