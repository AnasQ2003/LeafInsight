const images = {
  LOGO: require('./logo.png'),
};

export default images;
