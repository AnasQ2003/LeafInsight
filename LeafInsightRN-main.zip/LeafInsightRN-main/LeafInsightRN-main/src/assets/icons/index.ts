const icons = {
  LANGUAGE: require('./language.png'),
  ARROW_LEFT: require('./back.png'),
  HOME: require('./home.png'),
  HOME_SELECTED: require('./home_selected.png'),
  NEW_SCAN: require('./camera.png'),
  NEW_SCAN_SELECTED: require('./camera_selected.png'),
  PROFILE: require('./profile.png'),
  PROFILE_SELECTED: require('./profile_selected.png'),
  PROFILE_PLACEHOLDER: require('./profile_placeholder.png'),
  EDIT: require('./edit.png'),
  ABOUT_US: require('./about.png'),
  TERMS_AND_CONDITIONS: require('./terms.png'),
};

export default icons;
