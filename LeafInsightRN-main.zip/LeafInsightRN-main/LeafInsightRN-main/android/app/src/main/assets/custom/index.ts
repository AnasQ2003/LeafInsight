const fonts = {
  APP_FONT_REGULAR: 'Raleway-Regular',
  APP_FONT_BOLD: 'Raleway-Bold',
  APP_FONT_MEDIUM: 'Raleway-Medium',
  APP_FONT_SEMIBOLD: 'Raleway-SemiBold',
  APP_FONT_THIN: 'Raleway-Thin',
  APP_FONT_LIGHT: 'Raleway-Light',
};

export default fonts;
