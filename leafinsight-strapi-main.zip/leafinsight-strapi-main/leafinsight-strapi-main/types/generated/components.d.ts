/*
 * The app doesn't have any components yet.
 */
