export default () => ({
  "users-permissions": {
    config: {
      register: {
        allowedFields: ["name"],
      },
    },
  },
});
