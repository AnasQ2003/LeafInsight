import fs from "fs";

export const printFormData = (formData) => {
  formData.forEach((value, key) => {
    console.log(`${key}: ${value}`);
  });
};

export const createBlob = (image: any) => {
  const fileStream = fs.createReadStream(image.filepath);
  return {
    fileStream,
    config: {
      filename: image.originalname,
      contentType: image.mimetype,
    },
  };
};

const BASE_URL = process.env.BASE_URL;
export const getStrapiImageUrl = (image: any) => {
  return `${BASE_URL}${image.url}`;
};
