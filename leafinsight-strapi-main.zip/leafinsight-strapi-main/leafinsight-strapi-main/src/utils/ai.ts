import { printFormData } from ".";
import FormData from "form-data";

const AI_ENDPOINT = process.env.AI_ENDPOINT;
const AI_TOKEN = process.env.AI_TOKEN;

interface PredictDiseaseResponse {
  plantName: string;
  diseaseName: string;
  mdBlog: string;
}

export const predictDisease = async (imageUrl: string, locale: string): Promise<PredictDiseaseResponse> => {
  const payload = {
    imageUrl: imageUrl,
    token: AI_TOKEN,
    language: locale,
  };

  console.log("PAYLOAD", payload);

  const response = await fetch(AI_ENDPOINT, {
    method: "POST",
    body: JSON.stringify(payload),
    headers: {
      "Content-Type": "application/json",
    },
  });

  const data = await response.json();
  return data as PredictDiseaseResponse;
};
