import { Core } from "@strapi/strapi";

export const deleteAsset = async (strapi, file) => {
  try {
    if (file) {
      await strapi.plugins.upload.services.upload.remove(file);
    }
  } catch (error) {
    throw error;
  }
};

export const uploadAssets = async (strapi: Core.Strapi, files) => {
  if (files) {
    const uploadImages = await strapi.plugins.upload.services.upload.upload({
      data: {},
      files: files,
    });
    return uploadImages;
  }

  return [];
};
