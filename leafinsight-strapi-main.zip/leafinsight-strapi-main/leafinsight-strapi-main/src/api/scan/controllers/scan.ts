/**
 * scan controller
 */

import { factories } from "@strapi/strapi";
import { uploadAssets } from "../../../utils/assets-helper";
import { predictDisease } from "../../../utils/ai";
import { createBlob, getStrapiImageUrl } from "../../../utils";

export default factories.createCoreController("api::scan.scan", ({ strapi }) => ({
  create: async (ctx) => {
    try {
      // Getting Data
      const { image }: any = ctx.request.files || {};
      const userId = ctx.state.user.id;
      const locale = ctx.query.locale || "en";

      //   Validation
      if (!image) {
        return ctx.badRequest("image is required");
      }

      //   Processing
      const [uploadedImage] = await uploadAssets(strapi, [image]);
      const imageId = uploadedImage.id;
      console.log("UPLOADED_IMAGE", uploadedImage);
      const imageUrl = getStrapiImageUrl(uploadedImage);
      const aiResponse = await predictDisease(imageUrl, locale as string);

      console.log("AI_RESPONSE", aiResponse);

      if (!aiResponse?.diseaseName || !aiResponse?.plantName) {
        return ctx.badRequest("Unable to predict disease");
      }

      //   Creating Response
      const createPayload = {
        user: userId,
        image: imageId,
        plantName: aiResponse.plantName,
        diseaseName: aiResponse.diseaseName,
        mdBlog: aiResponse.mdBlog,
      };

      const scan = await strapi.db.query("api::scan.scan").create({
        data: createPayload,
      });

      return {
        success: true,
        data: scan,
      };
    } catch (err) {
      return ctx.badRequest(`Error processing scan: ${err.message}`);
    }
  },

  async find(ctx) {
    try {
      const page = parseInt(ctx.query.page as string) || 1;
      const pageSize = parseInt(ctx.query.pageSize as string) || 10;
      const userId = ctx.state.user.id;
      if (!userId) {
        return ctx.badRequest("User not found");
      }

      delete ctx.query.page;
      delete ctx.query.pageSize;

      console.log("USER_ID", userId);

      // Instead of modifying ctx.query, let's use the direct database query approach
      const entities = await strapi.db.query("api::scan.scan").findMany({
        where: {
          user: {
            id: userId,
          },
        },
        populate: ["user", "image"],
        orderBy: { createdAt: "DESC" },
        limit: pageSize,
        offset: (page - 1) * pageSize,
      });

      const count = await strapi.db.query("api::scan.scan").count({
        where: {
          user: {
            id: userId,
          },
        },
      });

      return {
        data: entities,
        meta: {
          pagination: {
            page: page,
            pageSize: pageSize,
            pageCount: Math.ceil(count / pageSize),
            total: count,
          },
        },
      };
    } catch (err) {
      return ctx.badRequest(`Error finding scans: ${err.message}`);
    }
  },
}));
