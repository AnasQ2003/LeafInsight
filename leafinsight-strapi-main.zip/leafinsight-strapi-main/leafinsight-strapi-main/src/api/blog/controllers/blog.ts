/**
 * blog controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController("api::blog.blog", ({ strapi }) => ({
  async find(ctx) {
    const page = ctx.query.page || 1;
    const pageSize = ctx.query.pageSize || 10;

    delete ctx.query.page;
    delete ctx.query.pageSize;

    ctx.query = {
      sort: "createdAt:desc",
      ...ctx.query,
      populate: "*",
      pagination: {
        page,
        pageSize,
      },
    };

    return super.find(ctx);
  },
}));
