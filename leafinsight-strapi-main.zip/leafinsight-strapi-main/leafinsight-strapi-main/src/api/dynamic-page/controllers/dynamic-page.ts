/**
 * dynamic-page controller
 */

import { factories } from "@strapi/strapi";

export default factories.createCoreController("api::dynamic-page.dynamic-page", ({ strapi }) => ({
  async findOne(ctx) {
    const { id } = ctx.params;
    const locale = ctx.query.locale || "en";

    const page = await strapi.db.query("api::dynamic-page.dynamic-page").findOne({
      where: {
        url: id,
        locale: locale,
      },
    });

    if (!page) {
      return ctx.notFound("Page not found");
    }

    return {
      data: page,
    };
  },
}));
